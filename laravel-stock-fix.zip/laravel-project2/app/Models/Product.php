<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class Product extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'product_category_id',
        'name', 'slug', 'description', 'sku',
        'price', 'sale_price',
        'stock', 'track_stock',
        'main_image',
        'images',          // JSON array of additional image paths
        'is_active',
        'is_featured',
    ];

    protected $casts = [
        'price'       => 'decimal:2',
        'sale_price'  => 'decimal:2',
        'stock'       => 'integer',
        'track_stock' => 'boolean',
        'images'      => 'array',
        'is_active'   => 'boolean',
        'is_featured' => 'boolean',
    ];

    protected static function boot()
    {
        parent::boot();
        static::creating(fn($m) =>
            $m->slug = $m->slug ?: Str::slug($m->name) . '-' . Str::random(5)
        );
    }

    // ── Relationships ──────────────────────────────────────────────────

    public function category()  { return $this->belongsTo(ProductCategory::class, 'product_category_id'); }
    public function cartItems() { return $this->hasMany(CartItem::class); }
    public function orderItems(){ return $this->hasMany(OrderItem::class); }
    public function reviews()   { return $this->hasMany(ProductReview::class); }
    public function approvedReviews() {
        return $this->hasMany(ProductReview::class)->where('status', 'approved')->latest();
    }

    // ── Scopes ─────────────────────────────────────────────────────────

    public function scopeActive($q)   { return $q->where('is_active', true); }
    public function scopeFeatured($q) { return $q->where('is_featured', true); }
    public function scopeInStock($q)  {
        return $q->where(fn($q) =>
            $q->where('track_stock', false)->orWhere('stock', '>', 0)
        );
    }

    // ── Price helpers ──────────────────────────────────────────────────

    public function currentPrice(): float
    {
        return (float) ($this->sale_price ?? $this->price);
    }

    public function isOnSale(): bool
    {
        return ! is_null($this->sale_price) && (float) $this->sale_price < (float) $this->price;
    }

    public function inStock(): bool
    {
        return ! $this->track_stock || $this->stock > 0;
    }

    public function decrementStock(int $qty = 1): void
    {
        if ($this->track_stock) {
            // Use MAX(0, stock - qty) to prevent unsigned integer underflow.
            // The checkout controller validates stock before calling this,
            // but this is a safety net in case of race conditions.
            $this->newQuery()
                ->where('id', $this->id)
                ->update([
                    'stock' => \DB::raw("GREATEST(0, stock - {$qty})"),
                ]);
            $this->refresh();
        }
    }

    // ── Image helpers ──────────────────────────────────────────────────

    /**
     * All images: main image first, then gallery images.
     * Returns an array of storage paths.
     */
    public function allImages(): array
    {
        $all = [];
        if ($this->main_image) {
            $all[] = $this->main_image;
        }
        foreach ($this->images ?? [] as $img) {
            if ($img && $img !== $this->main_image) {
                $all[] = $img;
            }
        }
        return $all;
    }

    /**
     * Full public URLs for all images.
     */
    public function allImageUrls(): array
    {
        return array_map(fn($path) => asset('storage/' . $path), $this->allImages());
    }

    // ── Review helpers ─────────────────────────────────────────────────

    /**
     * Average rating across approved reviews (rounded to 1 decimal).
     */
    public function averageRating(): float
    {
        return round($this->approvedReviews()->avg('rating') ?? 0, 1);
    }

    /**
     * Count of approved reviews.
     */
    public function reviewCount(): int
    {
        return $this->approvedReviews()->count();
    }

    /**
     * Rating distribution: ['5'=>12, '4'=>8, ...] for approved reviews.
     */
    public function ratingDistribution(): array
    {
        $dist = $this->approvedReviews()
            ->selectRaw('rating, count(*) as cnt')
            ->groupBy('rating')
            ->pluck('cnt', 'rating')
            ->toArray();

        $result = [];
        for ($i = 5; $i >= 1; $i--) {
            $result[$i] = $dist[$i] ?? 0;
        }
        return $result;
    }

    /**
     * Check if a user has already reviewed this product.
     */
    public function hasReviewFrom(int $userId): bool
    {
        return $this->reviews()->where('user_id', $userId)->exists();
    }
}
