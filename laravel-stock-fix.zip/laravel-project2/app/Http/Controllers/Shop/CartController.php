<?php

namespace App\Http\Controllers\Shop;

use App\Http\Controllers\Controller;
use App\Models\CartItem;
use App\Models\Product;
use Illuminate\Http\Request;

class CartController extends Controller
{
    private function cartQuery()
    {
        return auth()->check()
            ? CartItem::where('user_id', auth()->id())
            : CartItem::where('session_id', session()->getId());
    }

    private function cartData(): array
    {
        return auth()->check()
            ? ['user_id' => auth()->id(), 'session_id' => null]
            : ['user_id' => null, 'session_id' => session()->getId()];
    }

    public function index()
    {
        $items    = $this->cartQuery()->with('product.category')->get();
        $subtotal = $items->sum(fn($i) => $i->product->currentPrice() * $i->quantity);

        return view('shop.cart.index', compact('items', 'subtotal'));
    }

    public function add(Request $request, Product $product)
    {
        abort_unless($product->is_active && $product->inStock(), 404);

        $request->validate(['quantity' => 'nullable|integer|min:1|max:100']);
        $qty = (int) $request->input('quantity', 1);

        // How many are already in the cart?
        $existing    = $this->cartQuery()->where('product_id', $product->id)->first();
        $currentQty  = $existing ? $existing->quantity : 0;
        $newQty      = $currentQty + $qty;

        // Cap to available stock
        if ($product->track_stock) {
            $stock = (int) $product->stock;
            if ($currentQty >= $stock) {
                return redirect()->back()
                    ->with('error', "\"{$product->name}\" is already at maximum stock quantity in your cart.");
            }
            if ($newQty > $stock) {
                $qty    = $stock - $currentQty;   // only add what's left
                $newQty = $stock;
            }
        }

        if ($existing) {
            $existing->update(['quantity' => $newQty]);
        } else {
            CartItem::create(array_merge($this->cartData(), [
                'product_id' => $product->id,
                'quantity'   => $qty,
            ]));
        }

        return redirect()->route('cart.index')
            ->with('success', "\"{$product->name}\" added to cart.");
    }

    public function update(Request $request, CartItem $cartItem)
    {
        $this->authorizeCartItem($cartItem);

        $request->validate(['quantity' => 'required|integer|min:1|max:100']);
        $qty = (int) $request->quantity;

        // Cap to available stock
        $product = $cartItem->product;
        if ($product->track_stock) {
            $stock = (int) $product->stock;
            if ($qty > $stock) {
                return redirect()->route('cart.index')
                    ->with('error', "\"{$product->name}\" only has {$stock} unit(s) in stock. Quantity adjusted.");
            }
        }

        $cartItem->update(['quantity' => $qty]);

        return redirect()->route('cart.index')->with('success', 'Cart updated.');
    }

    public function remove(CartItem $cartItem)
    {
        $this->authorizeCartItem($cartItem);
        $cartItem->delete();

        return redirect()->route('cart.index')->with('success', 'Item removed.');
    }

    public function clear()
    {
        $this->cartQuery()->delete();
        return redirect()->route('cart.index')->with('success', 'Cart cleared.');
    }

    private function authorizeCartItem(CartItem $item): void
    {
        if (auth()->check()) {
            abort_unless($item->user_id === auth()->id(), 403);
        } else {
            abort_unless($item->session_id === session()->getId(), 403);
        }
    }
}
