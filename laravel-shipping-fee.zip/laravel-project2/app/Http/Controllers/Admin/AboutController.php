<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SiteSetting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class AboutController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'active', 'admin']);
    }

    public function edit()
    {
        $settings = [
            'about_title'      => SiteSetting::get('about_title', 'About Us'),
            'about_subtitle'   => SiteSetting::get('about_subtitle'),
            'about_body'       => SiteSetting::get('about_body'),
            'about_vision'     => SiteSetting::get('about_vision'),
            'about_mission'    => SiteSetting::get('about_mission'),
            'contact_email'    => SiteSetting::get('contact_email'),
            'contact_phone'    => SiteSetting::get('contact_phone'),
            'contact_address'  => SiteSetting::get('contact_address'),
            'contact_hours'    => SiteSetting::get('contact_hours'),
            'social_instagram' => SiteSetting::get('social_instagram'),
            'social_facebook'  => SiteSetting::get('social_facebook'),
            'social_twitter'   => SiteSetting::get('social_twitter'),
            'social_youtube'   => SiteSetting::get('social_youtube'),
            'kakao_id'         => SiteSetting::get('kakao_id'),
            'map_embed_url'    => SiteSetting::get('map_embed_url'),
            'site_logo'               => SiteSetting::get('site_logo'),
            'shipping_fee'           => SiteSetting::get('shipping_fee', '3000'),
            'shipping_free_threshold'=> SiteSetting::get('shipping_free_threshold', '0'),
        ];

        return view('admin.about.edit', compact('settings'));
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'about_title'      => 'required|string|max:200',
            'about_subtitle'   => 'nullable|string|max:300',
            'about_body'       => 'nullable|string',
            'about_vision'     => 'nullable|string',
            'about_mission'    => 'nullable|string',
            'contact_email'    => 'nullable|email|max:150',
            'contact_phone'    => 'nullable|string|max:50',
            'contact_address'  => 'nullable|string|max:300',
            'contact_hours'    => 'nullable|string|max:200',
            'social_instagram' => 'nullable|url|max:300',
            'social_facebook'  => 'nullable|url|max:300',
            'social_twitter'   => 'nullable|url|max:300',
            'social_youtube'   => 'nullable|url|max:300',
            'kakao_id'         => 'nullable|string|max:100',
            'map_embed_url'           => 'nullable|string|max:2000',
            'shipping_fee'           => 'nullable|numeric|min:0',
            'shipping_free_threshold'=> 'nullable|numeric|min:0',
        ]);

        SiteSetting::setMany($data);

        return redirect()->route('admin.about.edit')
            ->with('success', 'About Us page updated successfully.');
    }

    /** Upload / replace the site logo */
    public function uploadLogo(Request $request)
    {
        $request->validate([
            'site_logo' => 'required|image|max:2048|mimes:png,jpg,jpeg,svg,webp',
        ]);

        $old = SiteSetting::get('site_logo');
        if ($old && Storage::disk('public')->exists($old)) {
            Storage::disk('public')->delete($old);
        }

        $path = $request->file('site_logo')->store('site', 'public');
        SiteSetting::set('site_logo', $path);

        return redirect()->route('admin.about.edit')
            ->with('success', 'Logo uploaded successfully.');
    }

    /** Remove the site logo */
    public function removeLogo()
    {
        $old = SiteSetting::get('site_logo');
        if ($old && Storage::disk('public')->exists($old)) {
            Storage::disk('public')->delete($old);
        }
        SiteSetting::set('site_logo', null);

        return redirect()->route('admin.about.edit')
            ->with('success', 'Logo removed.');
    }
}
