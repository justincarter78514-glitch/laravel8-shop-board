<?php

namespace App\Http\Controllers\Shop;

use App\Http\Controllers\Controller;
use App\Mail\LowStockAlert;
use App\Models\CartItem;
use App\Models\Coupon;
use App\Models\CouponUsage;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

class CheckoutController extends Controller
{
    // Low-stock threshold (units)
    const LOW_STOCK_THRESHOLD = 5;

    public function __construct()
    {
        $this->middleware(['auth', 'active']);
    }

    public function index()
    {
        $items = CartItem::where('user_id', auth()->id())->with('product')->get();

        if ($items->isEmpty()) {
            return redirect()->route('cart.index')->with('error', 'Your cart is empty.');
        }

        $subtotal     = $items->sum(fn($i) => $i->product->currentPrice() * $i->quantity);
        $couponSession = session('coupon');
        $discount     = $couponSession['discount'] ?? 0;
        $couponCode   = $couponSession['code'] ?? null;

        return view('shop.orders.checkout', compact('items','subtotal','discount','couponCode'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'shipping_name'    => 'required|string|max:100',
            'shipping_email'   => 'required|email|max:150',
            'shipping_phone'   => 'nullable|string|max:20',
            'shipping_address' => 'required|string|max:300',
            'shipping_city'    => 'required|string|max:100',
            'shipping_zip'     => 'required|string|max:20',
            'shipping_country' => 'required|string|size:2',
            'payment_method'   => 'required|in:card,bank_transfer,cash_on_delivery',
            'notes'            => 'nullable|string|max:500',
        ]);

        $cartItems = CartItem::where('user_id', auth()->id())->with('product')->get();

        if ($cartItems->isEmpty()) {
            return redirect()->route('cart.index')->with('error', 'Your cart is empty.');
        }

        DB::transaction(function () use ($data, $cartItems) {
            $subtotal = $cartItems->sum(fn($i) => $i->product->currentPrice() * $i->quantity);
            $freeThreshold = (float) \App\Models\SiteSetting::get("shipping_free_threshold", 0);
            $shipping = ($freeThreshold > 0 && $subtotal >= $freeThreshold)
                ? 0
                : (float) \App\Models\SiteSetting::get("shipping_fee", 3000);

            // Apply coupon from session
            $couponSession = session('coupon');
            $discount      = 0;
            $couponId      = null;
            $couponCode    = null;

            if ($couponSession) {
                $coupon = Coupon::find($couponSession['id']);
                if ($coupon && ! $coupon->validateForUser(auth()->id(), $subtotal)) {
                    $discount   = $coupon->calculateDiscount($subtotal);
                    $couponId   = $coupon->id;
                    $couponCode = $coupon->code;
                }
            }

            $total = max(0, $subtotal + $shipping - $discount);

            $order = Order::create(array_merge($data, [
                'user_id'      => auth()->id(),
                'subtotal'     => $subtotal,
                'shipping_fee' => $shipping,
                'discount'     => $discount,
                'total'        => $total,
                'status'       => 'pending',
                'coupon_id'    => $couponId,
                'coupon_code'  => $couponCode,
            ]));

            foreach ($cartItems as $item) {
                OrderItem::create([
                    'order_id'     => $order->id,
                    'product_id'   => $item->product_id,
                    'product_name' => $item->product->name,
                    'product_sku'  => $item->product->sku,
                    'unit_price'   => $item->product->currentPrice(),
                    'quantity'     => $item->quantity,
                    'subtotal'     => $item->product->currentPrice() * $item->quantity,
                ]);

                $item->product->decrementStock($item->quantity);

                // Low-stock alert to admins
                if ($item->product->track_stock && $item->product->fresh()->stock <= self::LOW_STOCK_THRESHOLD) {
                    $this->notifyAdminsLowStock($item->product->fresh());
                }
            }

            // Record coupon usage
            if ($couponId) {
                CouponUsage::create([
                    'coupon_id'       => $couponId,
                    'user_id'         => auth()->id(),
                    'order_id'        => $order->id,
                    'discount_amount' => $discount,
                ]);
                Coupon::find($couponId)->increment('usage_count');
            }

            CartItem::where('user_id', auth()->id())->delete();
            session()->forget('coupon');
            session(['last_order_id' => $order->id]);
        });

        return redirect()->route('orders.confirmation')->with('success', 'Order placed successfully!');
    }

    public function confirmation()
    {
        $orderId = session('last_order_id');
        $order   = $orderId ? Order::with('items.product')->find($orderId) : null;
        return view('shop.orders.confirmation', compact('order'));
    }

    private function notifyAdminsLowStock($product): void
    {
        $admins = User::where('is_admin', true)->where('is_active', true)->get();
        foreach ($admins as $admin) {
            try {
                Mail::to($admin->email)->send(new LowStockAlert($product, self::LOW_STOCK_THRESHOLD));
            } catch (\Exception $e) {
                logger()->error('Low stock email failed: ' . $e->getMessage());
            }
        }
    }
}
