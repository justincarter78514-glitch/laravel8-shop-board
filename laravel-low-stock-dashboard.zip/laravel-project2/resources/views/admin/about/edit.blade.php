@extends('layouts.admin')
@section('title', 'Manage About Us')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h5 class="mb-0">About Us &amp; Site Settings</h5>
    <a href="{{ route('about') }}" target="_blank" class="btn btn-sm btn-outline-secondary">
        <i class="bi bi-eye me-1"></i>Preview Page
    </a>
</div>

{{-- ── LOGO CARD (its own form) ──────────────────────────────────────────── --}}
<div class="card border-0 shadow-sm mb-4">
    <div class="card-header bg-white fw-semibold">
        <i class="bi bi-image me-2"></i>Site Logo
        <span class="text-muted fw-normal small ms-2">Displayed in the navbar and footer on all pages</span>
    </div>
    <div class="card-body p-4">
        <div class="d-flex align-items-start gap-4 flex-wrap">

            {{-- Preview area --}}
            <div class="flex-shrink-0 text-center">
                <div class="border rounded p-3 mb-1 d-flex align-items-center justify-content-center"
                     style="min-width:160px; min-height:70px; background:#1e2a3a;">
                    @if($settings['site_logo'])
                        <img src="{{ asset('storage/'.$settings['site_logo']) }}"
                             id="logoPreviewImg"
                             style="max-height:48px; max-width:160px; object-fit:contain;"
                             alt="Logo">
                    @else
                        <img id="logoPreviewImg" src="" alt=""
                             style="max-height:48px; max-width:160px; object-fit:contain; display:none;">
                        <span id="logoPlaceholderText" class="text-white-50 small">No logo</span>
                    @endif
                </div>
                <div class="text-muted" style="font-size:.7rem;">Preview on dark background</div>
            </div>

            {{-- Upload / Remove --}}
            <div class="flex-grow-1">
                <form method="POST" action="{{ route('admin.about.logo') }}"
                      enctype="multipart/form-data" class="mb-2">
                    @csrf
                    <label class="form-label small fw-semibold mb-1">Upload New Logo</label>
                    <div class="input-group">
                        <input type="file" name="site_logo"
                               class="form-control @error('site_logo') is-invalid @enderror"
                               accept="image/png,image/jpeg,image/svg+xml,image/webp"
                               onchange="previewLogo(this)">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-upload me-1"></i>Upload
                        </button>
                    </div>
                    <div class="form-text">PNG / SVG / WebP recommended · Max 2 MB · Transparent background works best</div>
                    @error('site_logo')
                        <div class="text-danger small mt-1">{{ $message }}</div>
                    @enderror
                </form>

                @if($settings['site_logo'])
                <form method="POST" action="{{ route('admin.about.logo.remove') }}"
                      onsubmit="return confirm('Remove the current logo?')">
                    @csrf @method('DELETE')
                    <button type="submit" class="btn btn-sm btn-outline-danger">
                        <i class="bi bi-trash me-1"></i>Remove Logo
                    </button>
                </form>
                @endif
            </div>
        </div>
    </div>
</div>

{{-- ── MAIN CONTENT FORM ─────────────────────────────────────────────────── --}}
<form method="POST" action="{{ route('admin.about.update') }}" id="aboutForm">
@csrf @method('PUT')

<div class="row g-4">

    <div class="col-lg-8">

        {{-- Page Content --}}
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white fw-semibold">
                <i class="bi bi-building me-2"></i>Page Content
            </div>
            <div class="card-body p-4">

                <div class="mb-3">
                    <label class="form-label fw-semibold">Title <span class="text-danger">*</span></label>
                    <input type="text" name="about_title"
                           class="form-control @error('about_title') is-invalid @enderror"
                           value="{{ old('about_title', $settings['about_title']) }}"
                           required>
                    @error('about_title')<div class="invalid-feedback">{{ $message }}</div>@enderror
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Subtitle</label>
                    <input type="text" name="about_subtitle" class="form-control"
                           value="{{ old('about_subtitle', $settings['about_subtitle']) }}"
                           placeholder="Short tagline shown under the title">
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Our Story</label>
                    <textarea name="about_body" class="form-control" rows="7"
                              placeholder="Company history, background…">{{ old('about_body', $settings['about_body']) }}</textarea>
                </div>

                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Vision</label>
                        <textarea name="about_vision" class="form-control" rows="3"
                                  placeholder="Long-term vision…">{{ old('about_vision', $settings['about_vision']) }}</textarea>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Mission</label>
                        <textarea name="about_mission" class="form-control" rows="3"
                                  placeholder="Mission statement…">{{ old('about_mission', $settings['about_mission']) }}</textarea>
                    </div>
                </div>
            </div>
        </div>

        {{-- Map --}}
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white fw-semibold">
                <i class="bi bi-map me-2"></i>Map Embed
            </div>
            <div class="card-body p-4">
                <label class="form-label fw-semibold">Google Maps Embed URL</label>
                <input type="text" name="map_embed_url" class="form-control"
                       value="{{ old('map_embed_url', $settings['map_embed_url']) }}"
                       placeholder="https://www.google.com/maps/embed?pb=…">
                <div class="form-text">
                    Google Maps → Share → Embed a map → copy the <code>src</code> value from the iframe.
                </div>
                @if($settings['map_embed_url'])
                <div class="mt-3 ratio ratio-21x9 rounded overflow-hidden border">
                    <iframe src="{{ $settings['map_embed_url'] }}" style="border:0;"
                            allowfullscreen loading="lazy"></iframe>
                </div>
                @endif
            </div>
        </div>

    </div>

    {{-- RIGHT: Contact + Social --}}
    <div class="col-lg-4">

        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white fw-semibold">
                <i class="bi bi-telephone me-2"></i>Contact Info
            </div>
            <div class="card-body p-4">
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Email</label>
                    <div class="input-group input-group-sm">
                        <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                        <input type="email" name="contact_email" class="form-control"
                               value="{{ old('contact_email', $settings['contact_email']) }}"
                               placeholder="contact@example.com">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Phone</label>
                    <div class="input-group input-group-sm">
                        <span class="input-group-text"><i class="bi bi-telephone"></i></span>
                        <input type="text" name="contact_phone" class="form-control"
                               value="{{ old('contact_phone', $settings['contact_phone']) }}"
                               placeholder="010-1234-5678">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Address</label>
                    <textarea name="contact_address" class="form-control form-control-sm" rows="2"
                              placeholder="123 Main St, Seoul">{{ old('contact_address', $settings['contact_address']) }}</textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Business Hours</label>
                    <input type="text" name="contact_hours" class="form-control form-control-sm"
                           value="{{ old('contact_hours', $settings['contact_hours']) }}"
                           placeholder="Mon–Fri 09:00–18:00">
                </div>
                <div>
                    <label class="form-label small fw-semibold">KakaoTalk ID</label>
                    <input type="text" name="kakao_id" class="form-control form-control-sm"
                           value="{{ old('kakao_id', $settings['kakao_id']) }}"
                           placeholder="your_kakao_id">
                </div>
            </div>
        </div>

        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white fw-semibold">
                <i class="bi bi-share me-2"></i>Social Media
            </div>
            <div class="card-body p-4">
                @foreach([
                    ['key'=>'social_instagram','icon'=>'instagram','label'=>'Instagram'],
                    ['key'=>'social_facebook', 'icon'=>'facebook', 'label'=>'Facebook'],
                    ['key'=>'social_twitter',  'icon'=>'twitter-x','label'=>'Twitter / X'],
                    ['key'=>'social_youtube',  'icon'=>'youtube',  'label'=>'YouTube'],
                ] as $s)
                <div class="mb-3">
                    <label class="form-label small fw-semibold">{{ $s['label'] }}</label>
                    <div class="input-group input-group-sm">
                        <span class="input-group-text"><i class="bi bi-{{ $s['icon'] }}"></i></span>
                        <input type="url" name="{{ $s['key'] }}" class="form-control"
                               value="{{ old($s['key'], $settings[$s['key']]) }}"
                               placeholder="https://…">
                    </div>
                </div>
                @endforeach
            </div>
        </div>

        {{-- Shipping Settings --}}
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white fw-semibold">🚚 Shipping Settings</div>
            <div class="card-body p-4">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold small">Shipping Fee (₩)</label>
                        <div class="input-group">
                            <span class="input-group-text">₩</span>
                            <input type="number" name="shipping_fee" class="form-control"
                                   value="{{ old('shipping_fee', $settings['shipping_fee'] ?? 3000) }}"
                                   min="0" step="100">
                        </div>
                        <div class="form-text">Set to 0 for free shipping on all orders.</div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold small">Free Shipping Threshold (₩)</label>
                        <div class="input-group">
                            <span class="input-group-text">₩</span>
                            <input type="number" name="shipping_free_threshold" class="form-control"
                                   value="{{ old('shipping_free_threshold', $settings['shipping_free_threshold'] ?? 0) }}"
                                   min="0" step="1000">
                        </div>
                        <div class="form-text">Orders at or above this amount get free shipping. Set to 0 to disable.</div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold small">Low Stock Alert Threshold (units)</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-exclamation-triangle"></i></span>
                            <input type="number" name="low_stock_threshold" class="form-control"
                                   value="{{ old('low_stock_threshold', $settings['low_stock_threshold'] ?? 5) }}"
                                   min="0" step="1">
                        </div>
                        <div class="form-text">Products with stock at or below this number appear as a warning on the admin dashboard.</div>
                    </div>
                </div>
            </div>
        </div>

        <button type="submit" form="aboutForm" class="btn btn-primary w-100 py-2">
            <i class="bi bi-check-lg me-2"></i>Save All Changes
        </button>
    </div>
</div>
</form>
@endsection

@push('scripts')
<script>
function previewLogo(input) {
    if (!input.files || !input.files[0]) return;
    const reader = new FileReader();
    reader.onload = function(e) {
        const img         = document.getElementById('logoPreviewImg');
        const placeholder = document.getElementById('logoPlaceholderText');
        if (img) {
            img.src = e.target.result;
            img.style.display = 'block';
        }
        if (placeholder) placeholder.style.display = 'none';
    };
    reader.readAsDataURL(input.files[0]);
}
</script>
@endpush
