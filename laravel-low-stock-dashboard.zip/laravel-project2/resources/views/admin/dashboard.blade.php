@extends('layouts.admin')
@section('title', 'Dashboard')

@section('content')
@php
    $user             = auth()->user();
    $pendingArticles  = $user->hasPermission('approve_articles') ? \App\Models\Article::pending()->count() : null;
    $pendingComments  = $user->hasPermission('approve_comments') ? \App\Models\Comment::whereNull('instant_reply_id')->pending()->count() : null;
    $pendingReviews   = $user->hasPermission('manage_products')  ? \App\Models\ProductReview::pending()->count() : null;
    $totalOrders      = $user->hasPermission('manage_orders')    ? \App\Models\Order::count() : null;
    $totalProducts    = $user->hasPermission('manage_products')  ? \App\Models\Product::active()->count() : null;
    $totalUsers       = $user->isAdmin() ? \App\Models\User::count() : null;
    $recentOrders     = $user->hasPermission('manage_orders')
                            ? \App\Models\Order::with('user')->latest()->take(5)->get()
                            : collect();

    // Low-stock alert: only visible to users who can manage products
    $lowStockThreshold = (int) \App\Models\SiteSetting::get('low_stock_threshold', 5);
    $lowStockProducts  = $user->hasPermission('manage_products')
        ? \App\Models\Product::active()
            ->where('track_stock', true)
            ->where('stock', '>', 0)                  // in stock but running low
            ->where('stock', '<=', $lowStockThreshold)
            ->orderBy('stock')
            ->get()
        : collect();
    $outOfStockProducts = $user->hasPermission('manage_products')
        ? \App\Models\Product::active()
            ->where('track_stock', true)
            ->where('stock', '<=', 0)
            ->orderBy('name')
            ->get()
        : collect();
@endphp

{{-- ═══════════════════════════════════════════════════════
     LOW STOCK ALERT PANEL  (shown when there are issues)
═══════════════════════════════════════════════════════ --}}
@if($outOfStockProducts->isNotEmpty() || $lowStockProducts->isNotEmpty())
<div class="mb-4">

    {{-- Out of stock (critical) --}}
    @if($outOfStockProducts->isNotEmpty())
    <div class="alert border-0 mb-3 p-0 overflow-hidden" style="border-radius:14px!important;box-shadow:0 4px 20px rgba(239,68,68,.15);">
        <div class="d-flex align-items-center gap-3 px-4 py-3"
             style="background:linear-gradient(135deg,#ef4444,#b91c1c);color:#fff;">
            <i class="bi bi-x-circle-fill fs-4 flex-shrink-0"></i>
            <div>
                <div class="fw-bold">Out of Stock — {{ $outOfStockProducts->count() }} product(s)</div>
                <div class="small opacity-75">These products are unavailable to customers. Restock immediately.</div>
            </div>
        </div>
        <div style="background:#fff5f5;">
            @foreach($outOfStockProducts as $p)
            <div class="d-flex align-items-center justify-content-between px-4 py-2
                        {{ !$loop->last ? 'border-bottom' : '' }}"
                 style="border-color:#fee2e2!important;">
                <div class="d-flex align-items-center gap-3">
                    @if($p->main_image)
                    <img src="{{ asset('storage/'.$p->main_image) }}"
                         style="width:36px;height:36px;object-fit:cover;border-radius:8px;flex-shrink:0;">
                    @else
                    <div class="d-flex align-items-center justify-content-center bg-light rounded"
                         style="width:36px;height:36px;font-size:1.2rem;flex-shrink:0;">🛒</div>
                    @endif
                    <div>
                        <div class="fw-semibold small">{{ $p->name }}</div>
                        <div class="text-muted" style="font-size:.72rem;">{{ $p->category->name }}</div>
                    </div>
                </div>
                <div class="d-flex align-items-center gap-3">
                    <span class="badge bg-danger">Out of Stock</span>
                    <a href="{{ route('admin.products.edit', $p) }}"
                       class="btn btn-sm btn-outline-danger" style="font-size:.75rem;padding:3px 10px;">
                        Restock
                    </a>
                </div>
            </div>
            @endforeach
        </div>
    </div>
    @endif

    {{-- Low stock (warning) --}}
    @if($lowStockProducts->isNotEmpty())
    <div class="alert border-0 p-0 overflow-hidden" style="border-radius:14px!important;box-shadow:0 4px 20px rgba(245,158,11,.12);">
        <div class="d-flex align-items-center gap-3 px-4 py-3"
             style="background:linear-gradient(135deg,#f59e0b,#d97706);color:#fff;">
            <i class="bi bi-exclamation-triangle-fill fs-4 flex-shrink-0"></i>
            <div>
                <div class="fw-bold">
                    Low Stock — {{ $lowStockProducts->count() }} product(s)
                    <span class="badge ms-2"
                          style="background:rgba(255,255,255,.25);font-size:.7rem;">
                        Threshold: {{ $lowStockThreshold }} units
                    </span>
                </div>
                <div class="small opacity-75">
                    These products have {{ $lowStockThreshold }} or fewer units remaining.
                    You can change the threshold in
                    <a href="{{ route('admin.about.edit') }}" class="text-white fw-bold">Settings</a>.
                </div>
            </div>
        </div>
        <div style="background:#fffbeb;">
            @foreach($lowStockProducts as $p)
            <div class="d-flex align-items-center justify-content-between px-4 py-2
                        {{ !$loop->last ? 'border-bottom' : '' }}"
                 style="border-color:#fde68a!important;">
                <div class="d-flex align-items-center gap-3">
                    @if($p->main_image)
                    <img src="{{ asset('storage/'.$p->main_image) }}"
                         style="width:36px;height:36px;object-fit:cover;border-radius:8px;flex-shrink:0;">
                    @else
                    <div class="d-flex align-items-center justify-content-center bg-light rounded"
                         style="width:36px;height:36px;font-size:1.2rem;flex-shrink:0;">🛒</div>
                    @endif
                    <div>
                        <div class="fw-semibold small">{{ $p->name }}</div>
                        <div class="text-muted" style="font-size:.72rem;">{{ $p->category->name }}</div>
                    </div>
                </div>
                <div class="d-flex align-items-center gap-3">
                    {{-- Stock level bar --}}
                    <div class="text-end" style="min-width:100px;">
                        <div class="fw-bold small"
                             style="color:{{ $p->stock <= 2 ? '#dc2626' : '#d97706' }};">
                            {{ $p->stock }} left
                        </div>
                        <div class="progress" style="height:5px;width:90px;">
                            @php $pct = $lowStockThreshold > 0 ? min(100, round($p->stock / $lowStockThreshold * 100)) : 0; @endphp
                            <div class="progress-bar"
                                 style="width:{{ $pct }}%;background:{{ $p->stock <= 2 ? '#dc2626' : '#f59e0b' }};"></div>
                        </div>
                    </div>
                    <a href="{{ route('admin.products.edit', $p) }}"
                       class="btn btn-sm btn-outline-warning" style="font-size:.75rem;padding:3px 10px;">
                        Restock
                    </a>
                </div>
            </div>
            @endforeach
        </div>
    </div>
    @endif

</div>
@endif

{{-- ═══════════════════════════════════════════════════════
     WELCOME BANNER
═══════════════════════════════════════════════════════ --}}
<div class="p-4 mb-4 rounded-3"
     style="background:linear-gradient(135deg,#1a2332,#1e3a5f);color:#fff;">
    <div class="d-flex align-items-center justify-content-between flex-wrap gap-3">
        <div>
            <h5 class="fw-bold mb-1">
                Welcome back, {{ $user->name }}!
                @if($user->isAdmin())
                    <span class="badge bg-danger ms-2" style="font-size:.65rem;">Administrator</span>
                @else
                    <span class="badge bg-warning text-dark ms-2" style="font-size:.65rem;">Moderator</span>
                @endif
            </h5>
            <p class="mb-0 small" style="color:rgba(255,255,255,.55);">
                @if($user->isAdmin())
                    You have full access to all admin features.
                @else
                    Your granted permissions:
                    @foreach(array_keys(array_filter(\App\Models\User::availablePermissions(), fn($k) => $user->hasPermission($k), ARRAY_FILTER_USE_KEY)) as $perm)
                        <span class="badge bg-white bg-opacity-10 me-1"
                              style="font-size:.62rem;">{{ str_replace('_',' ',$perm) }}</span>
                    @endforeach
                @endif
            </p>
        </div>
        <span style="color:rgba(255,255,255,.3);font-size:.8rem;">
            {{ now()->format('l, F j, Y') }}
        </span>
    </div>
</div>

{{-- ═══════════════════════════════════════════════════════
     STATS CARDS
═══════════════════════════════════════════════════════ --}}
<div class="row g-3 mb-4">
    @foreach([
        ['cond'=>!is_null($pendingArticles), 'val'=>$pendingArticles, 'label'=>'Pending Articles', 'icon'=>'file-earmark-text','color'=>'#f59e0b','bg'=>'rgba(245,158,11,.1)'],
        ['cond'=>!is_null($pendingComments), 'val'=>$pendingComments, 'label'=>'Pending Comments', 'icon'=>'chat-dots',        'color'=>'#3b82f6','bg'=>'rgba(59,130,246,.1)'],
        ['cond'=>!is_null($pendingReviews),  'val'=>$pendingReviews,  'label'=>'Pending Reviews',  'icon'=>'star',             'color'=>'#8b5cf6','bg'=>'rgba(139,92,246,.1)'],
        ['cond'=>!is_null($totalOrders),     'val'=>$totalOrders,     'label'=>'Total Orders',     'icon'=>'receipt',          'color'=>'#22c55e','bg'=>'rgba(34,197,94,.1)'],
        ['cond'=>!is_null($totalProducts),   'val'=>$totalProducts,   'label'=>'Active Products',  'icon'=>'box-seam',         'color'=>'#f97316','bg'=>'rgba(249,115,22,.1)'],
        ['cond'=>!is_null($totalUsers),      'val'=>$totalUsers,      'label'=>'Registered Users', 'icon'=>'people',           'color'=>'#ec4899','bg'=>'rgba(236,72,153,.1)'],
    ] as $s)
    @if($s['cond'])
    <div class="col-sm-6 col-lg-4 col-xl-2">
        <div class="card border-0 shadow-sm p-3 h-100" style="border-radius:12px!important;">
            <div class="d-flex align-items-center gap-3">
                <div class="rounded-3 d-flex align-items-center justify-content-center flex-shrink-0"
                     style="width:44px;height:44px;background:{{ $s['bg'] }};">
                    <i class="bi bi-{{ $s['icon'] }}" style="color:{{ $s['color'] }};font-size:1.2rem;"></i>
                </div>
                <div>
                    <div class="fs-4 fw-bold" style="line-height:1;">{{ $s['val'] }}</div>
                    <div class="text-muted" style="font-size:.72rem;">{{ $s['label'] }}</div>
                </div>
            </div>
        </div>
    </div>
    @endif
    @endforeach
</div>

{{-- ═══════════════════════════════════════════════════════
     QUICK ACTIONS + MAIN CONTENT
═══════════════════════════════════════════════════════ --}}
<div class="row g-4">

    {{-- Quick actions --}}
    <div class="col-lg-4">
        <div class="card border-0 shadow-sm h-100" style="border-radius:14px!important;">
            <div class="card-header bg-white border-0 fw-bold pt-4 pb-2 px-4">Quick Actions</div>
            <div class="card-body px-4 pb-4 d-flex flex-column gap-2">

                @if($user->hasPermission('approve_articles') && $pendingArticles > 0)
                <a href="{{ route('admin.articles.index',['status'=>'pending']) }}"
                   class="btn text-start d-flex justify-content-between align-items-center"
                   style="background:#fffbeb;color:#92400e;border:1px solid #fde68a;">
                    <span><i class="bi bi-file-earmark-text me-2"></i>Review Articles</span>
                    <span class="badge" style="background:#f59e0b;">{{ $pendingArticles }}</span>
                </a>
                @endif

                @if($user->hasPermission('approve_comments') && $pendingComments > 0)
                <a href="{{ route('admin.comments.index',['status'=>'pending']) }}"
                   class="btn text-start d-flex justify-content-between align-items-center"
                   style="background:#eff6ff;color:#1e40af;border:1px solid #bfdbfe;">
                    <span><i class="bi bi-chat-dots me-2"></i>Review Comments</span>
                    <span class="badge bg-primary">{{ $pendingComments }}</span>
                </a>
                @endif

                @if($user->hasPermission('manage_products') && $pendingReviews > 0)
                <a href="{{ route('admin.reviews.index',['status'=>'pending']) }}"
                   class="btn text-start d-flex justify-content-between align-items-center"
                   style="background:#f5f3ff;color:#5b21b6;border:1px solid #ddd6fe;">
                    <span><i class="bi bi-star me-2"></i>Review Ratings</span>
                    <span class="badge" style="background:#8b5cf6;">{{ $pendingReviews }}</span>
                </a>
                @endif

                {{-- Low stock quick action --}}
                @if($user->hasPermission('manage_products') && ($lowStockProducts->isNotEmpty() || $outOfStockProducts->isNotEmpty()))
                <a href="{{ route('admin.products.index') }}"
                   class="btn text-start d-flex justify-content-between align-items-center"
                   style="background:#fff7ed;color:#9a3412;border:1px solid #fed7aa;">
                    <span><i class="bi bi-exclamation-triangle me-2"></i>Stock Issues</span>
                    <span class="badge bg-orange" style="background:#ea580c;">
                        {{ $outOfStockProducts->count() + $lowStockProducts->count() }}
                    </span>
                </a>
                @endif

                @if($user->hasPermission('manage_products'))
                <a href="{{ route('admin.products.create') }}"
                   class="btn btn-outline-success text-start">
                    <i class="bi bi-plus-circle me-2"></i>Add New Product
                </a>
                @endif
                @if($user->hasPermission('manage_categories'))
                <a href="{{ route('admin.categories.create') }}"
                   class="btn btn-outline-secondary text-start">
                    <i class="bi bi-folder-plus me-2"></i>Add Category
                </a>
                @endif
                @if($user->hasPermission('manage_instant_replies'))
                <a href="{{ route('admin.instant-replies.create') }}"
                   class="btn btn-outline-warning text-start">
                    <i class="bi bi-lightning me-2"></i>Add Instant Reply
                </a>
                @endif
                @if($user->isAdmin())
                <a href="{{ route('admin.notifications.create') }}"
                   class="btn btn-outline-primary text-start">
                    <i class="bi bi-bell-plus me-2"></i>Send Notification
                </a>
                <a href="{{ route('admin.hero-slides.index') }}"
                   class="btn btn-outline-dark text-start">
                    <i class="bi bi-collection-play me-2"></i>Manage Hero Slides
                </a>
                <a href="{{ route('admin.users.index') }}"
                   class="btn btn-outline-danger text-start">
                    <i class="bi bi-people me-2"></i>Manage Users
                </a>
                @endif
            </div>
        </div>
    </div>

    {{-- Recent orders or permission overview --}}
    <div class="col-lg-8">
        @if($recentOrders->isNotEmpty())
        <div class="card border-0 shadow-sm" style="border-radius:14px!important;">
            <div class="card-header bg-white border-0 d-flex justify-content-between align-items-center pt-4 pb-2 px-4">
                <span class="fw-bold">Recent Orders</span>
                <a href="{{ route('admin.orders.index') }}" class="btn btn-sm btn-outline-secondary">View All</a>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" style="font-size:.84rem;">
                    <thead style="background:#f8fafc;">
                        <tr>
                            <th class="px-4 py-3">Order #</th>
                            <th>Customer</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($recentOrders as $order)
                        <tr>
                            <td class="px-4">
                                <a href="{{ route('admin.orders.show',$order) }}"
                                   class="fw-semibold text-decoration-none">{{ $order->order_number }}</a>
                            </td>
                            <td>{{ $order->shipping_name }}</td>
                            <td class="fw-semibold">₩{{ number_format($order->total) }}</td>
                            <td>
                                @php $bc=match($order->status){
                                    'paid','delivered'=>'success','pending'=>'warning',
                                    'processing','shipped'=>'info',
                                    'cancelled','refunded'=>'danger',default=>'secondary'
                                }; @endphp
                                <span class="badge bg-{{ $bc }}">{{ ucfirst($order->status) }}</span>
                            </td>
                            <td class="text-muted small">{{ $order->created_at->format('M d, Y') }}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
        @else
        {{-- Permission overview for moderators with no order access --}}
        <div class="card border-0 shadow-sm" style="border-radius:14px!important;">
            <div class="card-header bg-white border-0 fw-bold pt-4 pb-2 px-4">Your Permission Overview</div>
            <div class="card-body px-4 pb-4">
                <div class="row g-3">
                    @foreach(\App\Models\User::availablePermissions() as $key => $label)
                    <div class="col-sm-6">
                        <div class="d-flex align-items-center gap-2 p-3 rounded-3"
                             style="background:{{ $user->hasPermission($key) ? '#f0fdf4':'#f8fafc' }};
                                    border:1px solid {{ $user->hasPermission($key) ? '#bbf7d0':'#e2e8f0' }};">
                            <i class="bi bi-{{ $user->hasPermission($key) ? 'check-circle-fill text-success':'x-circle text-muted' }}"></i>
                            <span class="small fw-semibold"
                                  style="color:{{ $user->hasPermission($key) ? '#166534':'#94a3b8' }};">
                                {{ $label }}
                            </span>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
        @endif
    </div>
</div>
@endsection
