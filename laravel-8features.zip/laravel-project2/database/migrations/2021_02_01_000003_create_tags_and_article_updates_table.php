<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTagsAndArticleUpdatesTable extends Migration
{
    public function up()
    {
        Schema::create('tags', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique();
            $table->string('slug')->unique();
            $table->timestamps();
        });

        Schema::create('article_tag', function (Blueprint $table) {
            $table->foreignId('article_id')->constrained()->onDelete('cascade');
            $table->foreignId('tag_id')->constrained()->onDelete('cascade');
            $table->primary(['article_id', 'tag_id']);
        });

        // Add view_count to articles
        Schema::table('articles', function (Blueprint $table) {
            $table->unsignedBigInteger('view_count')->default(0)->after('recommend_count');
        });

        // Add coupon fields to orders
        Schema::table('orders', function (Blueprint $table) {
            $table->foreignId('coupon_id')->nullable()->constrained('coupons')->onDelete('set null')->after('notes');
            $table->string('coupon_code')->nullable()->after('coupon_id');
        });
    }

    public function down()
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->dropForeign(['coupon_id']);
            $table->dropColumn(['coupon_id', 'coupon_code']);
        });
        Schema::table('articles', function (Blueprint $table) {
            $table->dropColumn('view_count');
        });
        Schema::dropIfExists('article_tag');
        Schema::dropIfExists('tags');
    }
}
