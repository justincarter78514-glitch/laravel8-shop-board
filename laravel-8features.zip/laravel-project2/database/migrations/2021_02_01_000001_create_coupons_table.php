<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCouponsTable extends Migration
{
    public function up()
    {
        Schema::create('coupons', function (Blueprint $table) {
            $table->id();
            $table->string('code')->unique();                    // e.g. SAVE20
            $table->string('description')->nullable();
            $table->enum('type', ['percent', 'fixed']);          // percent off or fixed amount
            $table->decimal('value', 10, 2);                    // 20 = 20% or ₩20,000
            $table->decimal('min_order_amount', 10, 2)->default(0); // minimum cart total
            $table->decimal('max_discount', 10, 2)->nullable();  // cap for percent coupons
            $table->unsignedInteger('usage_limit')->nullable();  // null = unlimited
            $table->unsignedInteger('usage_count')->default(0);
            $table->unsignedInteger('per_user_limit')->default(1);
            $table->boolean('is_active')->default(true);
            $table->timestamp('starts_at')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('coupon_usages', function (Blueprint $table) {
            $table->id();
            $table->foreignId('coupon_id')->constrained()->onDelete('cascade');
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->foreignId('order_id')->nullable()->constrained()->onDelete('set null');
            $table->decimal('discount_amount', 10, 2);
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('coupon_usages');
        Schema::dropIfExists('coupons');
    }
}
