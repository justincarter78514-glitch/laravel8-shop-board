<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Article;
use Illuminate\Http\Request;

class ArticleController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'active', 'can.admin:approve_articles']);
    }

    public function index(Request $request)
    {
        $status = in_array($request->status, ['pending','approved','rejected'])
            ? $request->status : 'pending';

        $articles = Article::with(['user','category','reviewer'])
            ->where('status', $status)->latest()->paginate(20);

        $counts = [
            'pending'  => Article::pending()->count(),
            'approved' => Article::approved()->count(),
            'rejected' => Article::rejected()->count(),
        ];

        return view('admin.articles.index', compact('articles', 'status', 'counts'));
    }

    public function show(Article $article)
    {
        $article->load(['user','category','comments.user','reviewer','tags']);
        return view('admin.articles.show', compact('article'));
    }

    public function approve(Article $article)
    {
        $article->update([
            'status'           => 'approved',
            'reviewed_by'      => auth()->id(),
            'reviewed_at'      => now(),
            'rejection_reason' => null,
        ]);
        return redirect()->back()->with('success', 'Article approved.');
    }

    public function reject(Request $request, Article $article)
    {
        $request->validate(['rejection_reason' => 'required|string|max:1000']);
        $article->update([
            'status'           => 'rejected',
            'reviewed_by'      => auth()->id(),
            'reviewed_at'      => now(),
            'rejection_reason' => $request->rejection_reason,
        ]);
        return redirect()->back()->with('success', 'Article rejected.');
    }

    /**
     * Bulk approve or reject selected articles.
     */
    public function bulkAction(Request $request)
    {
        $request->validate([
            'action'           => 'required|in:approve,reject',
            'ids'              => 'required|array|min:1',
            'ids.*'            => 'integer|exists:articles,id',
            'rejection_reason' => 'required_if:action,reject|nullable|string|max:500',
        ]);

        $articles = Article::whereIn('id', $request->ids)->get();
        $count    = $articles->count();

        foreach ($articles as $article) {
            if ($request->action === 'approve') {
                $article->update([
                    'status'           => 'approved',
                    'reviewed_by'      => auth()->id(),
                    'reviewed_at'      => now(),
                    'rejection_reason' => null,
                ]);
            } else {
                $article->update([
                    'status'           => 'rejected',
                    'reviewed_by'      => auth()->id(),
                    'reviewed_at'      => now(),
                    'rejection_reason' => $request->rejection_reason ?? 'Rejected by admin.',
                ]);
            }
        }

        $verb = $request->action === 'approve' ? 'Approved' : 'Rejected';
        return redirect()->back()->with('success', "{$verb} {$count} article(s) successfully.");
    }

    public function destroy(Article $article)
    {
        $article->forceDelete();
        return redirect()->route('admin.articles.index')->with('success', 'Article deleted.');
    }
}
