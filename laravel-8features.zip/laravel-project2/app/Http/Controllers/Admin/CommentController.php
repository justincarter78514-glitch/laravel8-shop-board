<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Comment;
use Illuminate\Http\Request;

class CommentController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'active', 'can.admin:approve_comments']);
    }

    public function index(Request $request)
    {
        $status = in_array($request->status, ['pending','approved','rejected'])
            ? $request->status : 'pending';

        $comments = Comment::with(['user','article','reviewer'])
            ->whereNull('instant_reply_id')
            ->where('status', $status)->latest()->paginate(30);

        $counts = [
            'pending'  => Comment::whereNull('instant_reply_id')->pending()->count(),
            'approved' => Comment::whereNull('instant_reply_id')->approved()->count(),
            'rejected' => Comment::whereNull('instant_reply_id')->where('status','rejected')->count(),
        ];

        return view('admin.comments.index', compact('comments', 'status', 'counts'));
    }

    public function approve(Comment $comment)
    {
        $comment->update([
            'status'           => 'approved',
            'reviewed_by'      => auth()->id(),
            'reviewed_at'      => now(),
            'rejection_reason' => null,
        ]);
        return redirect()->back()->with('success', 'Comment approved.');
    }

    public function reject(Request $request, Comment $comment)
    {
        $request->validate(['rejection_reason' => 'required|string|max:1000']);
        $comment->update([
            'status'           => 'rejected',
            'reviewed_by'      => auth()->id(),
            'reviewed_at'      => now(),
            'rejection_reason' => $request->rejection_reason,
        ]);
        return redirect()->back()->with('success', 'Comment rejected.');
    }

    /**
     * Bulk approve or reject selected comments.
     */
    public function bulkAction(Request $request)
    {
        $request->validate([
            'action'           => 'required|in:approve,reject',
            'ids'              => 'required|array|min:1',
            'ids.*'            => 'integer|exists:comments,id',
            'rejection_reason' => 'required_if:action,reject|nullable|string|max:500',
        ]);

        $comments = Comment::whereIn('id', $request->ids)->get();
        $count    = $comments->count();

        foreach ($comments as $comment) {
            if ($request->action === 'approve') {
                $comment->update([
                    'status'           => 'approved',
                    'reviewed_by'      => auth()->id(),
                    'reviewed_at'      => now(),
                    'rejection_reason' => null,
                ]);
            } else {
                $comment->update([
                    'status'           => 'rejected',
                    'reviewed_by'      => auth()->id(),
                    'reviewed_at'      => now(),
                    'rejection_reason' => $request->rejection_reason ?? 'Rejected by admin.',
                ]);
            }
        }

        $verb = $request->action === 'approve' ? 'Approved' : 'Rejected';
        return redirect()->back()->with('success', "{$verb} {$count} comment(s) successfully.");
    }

    public function destroy(Comment $comment)
    {
        $comment->delete();
        return redirect()->back()->with('success', 'Comment deleted.');
    }
}
