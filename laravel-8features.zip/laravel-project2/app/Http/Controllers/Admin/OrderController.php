<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Mail\OrderStatusChanged;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class OrderController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'active', 'can.admin:manage_orders']);
    }

    public function index(Request $request)
    {
        $status        = $request->input('status', 'all');
        $validStatuses = ['pending','paid','processing','shipped','delivered','cancelled','refunded'];

        $orders = Order::with('user')
            ->when($status !== 'all' && in_array($status, $validStatuses), fn($q) => $q->where('status', $status))
            ->when($request->search, fn($q) =>
                $q->where('order_number','like',"%{$request->search}%")
                  ->orWhere('shipping_email','like',"%{$request->search}%")
            )
            ->latest()->paginate(20);

        return view('admin.orders.index', compact('orders', 'status', 'validStatuses'));
    }

    public function show(Order $order)
    {
        $order->load(['user','items.product']);
        return view('admin.orders.show', compact('order'));
    }

    public function updateStatus(Request $request, Order $order)
    {
        $request->validate([
            'status' => 'required|in:pending,paid,processing,shipped,delivered,cancelled,refunded',
        ]);

        $previous = $order->status;
        $new      = $request->status;

        if ($previous === $new) {
            return redirect()->back()->with('info', 'Status is already ' . $new . '.');
        }

        $order->update(['status' => $new]);

        // Email customer on meaningful status changes
        $notifyOn = ['paid','processing','shipped','delivered','cancelled','refunded'];
        if (in_array($new, $notifyOn) && $order->shipping_email) {
            try {
                Mail::to($order->shipping_email)
                    ->send(new OrderStatusChanged($order->fresh(['items']), $previous));
            } catch (\Exception $e) {
                logger()->error('Order email failed: ' . $e->getMessage());
            }
        }

        return redirect()->back()
            ->with('success', "Status updated to [{$new}]." . (in_array($new,$notifyOn) ? ' Customer notified by email.' : ''));
    }
}
