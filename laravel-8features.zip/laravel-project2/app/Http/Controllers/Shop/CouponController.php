<?php

namespace App\Http\Controllers\Shop;

use App\Http\Controllers\Controller;
use App\Models\Coupon;
use Illuminate\Http\Request;

class CouponController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'active']);
    }

    /**
     * Validate and apply a coupon code to the session.
     * Called via AJAX from the checkout page.
     */
    public function apply(Request $request)
    {
        $request->validate(['code' => 'required|string']);

        $code = strtoupper(trim($request->code));

        $coupon = Coupon::active()->where('code', $code)->first();

        if (! $coupon) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid or expired coupon code.',
            ], 422);
        }

        // Calculate current cart subtotal
        $subtotal = \App\Models\CartItem::where('user_id', auth()->id())
            ->with('product')
            ->get()
            ->sum(fn($i) => $i->product->currentPrice() * $i->quantity);

        $error = $coupon->validateForUser(auth()->id(), $subtotal);
        if ($error) {
            return response()->json(['success' => false, 'message' => $error], 422);
        }

        $discount = $coupon->calculateDiscount($subtotal);

        // Store in session for checkout
        session(['coupon' => [
            'id'       => $coupon->id,
            'code'     => $coupon->code,
            'discount' => $discount,
        ]]);

        return response()->json([
            'success'  => true,
            'message'  => "Coupon applied! You save ₩" . number_format($discount),
            'discount' => $discount,
            'discount_formatted' => '₩' . number_format($discount),
        ]);
    }

    /** Remove coupon from session */
    public function remove()
    {
        session()->forget('coupon');
        return response()->json(['success' => true]);
    }
}
