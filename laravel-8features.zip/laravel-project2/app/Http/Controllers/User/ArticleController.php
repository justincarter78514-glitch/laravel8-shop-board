<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Article;
use App\Models\ArticleRecommendation;
use App\Models\Category;
use App\Models\InstantReply;
use App\Models\Tag;
use Illuminate\Http\Request;

class ArticleController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'active'])->except('index');
    }

    public function index(Request $request)
    {
        $query = Article::approved()->with(['user','category'])->withCount('approvedComments');

        if ($request->category_id) $query->where('category_id', $request->category_id);
        if ($request->tag)         $query->whereHas('tags', fn($q) => $q->where('slug', $request->tag));
        if ($request->search)      $query->where(fn($q) =>
            $q->where('title','like',"%{$request->search}%")
              ->orWhere('body','like',"%{$request->search}%")
        );

        $articles   = $query->latest()->paginate(15);
        $categories = Category::active()->ordered()->get();
        $popularTags = Tag::withCount(['articles' => fn($q) => $q->approved()])
            ->having('articles_count', '>', 0)
            ->orderByDesc('articles_count')
            ->take(20)->get();

        return view('user.articles.index', compact('articles','categories','popularTags'));
    }

    public function show(Article $article)
    {
        abort_unless($article->isApproved(), 404);

        $article->load(['user','category','approvedComments.user','tags']);

        // Increment view count (skip author's own views)
        $article->incrementView(auth()->id());

        $instantReplies = InstantReply::active()->ordered()->get();
        $related        = $article->related(3);
        $recommended    = $article->isRecommendedBy(auth()->user());

        return view('user.articles.show', compact('article','instantReplies','recommended','related'));
    }

    public function create()
    {
        $categories = Category::active()->ordered()->get();
        $allTags    = Tag::orderBy('name')->get();
        return view('user.articles.create', compact('categories','allTags'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'category_id' => 'required|exists:categories,id',
            'title'       => 'required|string|max:200',
            'body'        => 'required|string|min:10',
            'tags'        => 'nullable|string',
        ]);

        $data['user_id'] = auth()->id();
        $data['status']  = 'pending';
        unset($data['tags']);

        $article = Article::create($data);

        // Sync tags (comma-separated new or existing)
        if ($request->filled('tags')) {
            $tagIds = collect(explode(',', $request->tags))
                ->map(fn($t) => trim($t))
                ->filter()
                ->map(fn($name) => Tag::firstOrCreate(
                    ['slug' => \Illuminate\Support\Str::slug($name)],
                    ['name' => $name]
                )->id)
                ->toArray();

            $article->tags()->sync($tagIds);
        }

        return redirect()->route('articles.index')
            ->with('success', 'Your article has been submitted and is awaiting approval.');
    }

    public function recommend(Article $article)
    {
        abort_unless($article->isApproved(), 404);
        $user = auth()->user();

        $existing = ArticleRecommendation::where('article_id',$article->id)->where('user_id',$user->id)->first();

        if ($existing) {
            $existing->delete();
            $article->decrement('recommend_count');
            $message = 'Recommendation removed.';
        } else {
            ArticleRecommendation::create(['article_id'=>$article->id,'user_id'=>$user->id]);
            $article->increment('recommend_count');
            $message = 'Article recommended!';
        }

        return redirect()->back()->with('success', $message);
    }

    public function myArticles()
    {
        $articles = Article::where('user_id', auth()->id())
            ->with('category')->latest()->paginate(15);
        return view('user.articles.my-articles', compact('articles'));
    }
}
