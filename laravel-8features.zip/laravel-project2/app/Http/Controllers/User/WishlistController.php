<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Wishlist;

class WishlistController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'active']);
    }

    public function index()
    {
        $items = Wishlist::where('user_id', auth()->id())
            ->with('product.category')
            ->latest()
            ->paginate(12);

        return view('user.wishlist.index', compact('items'));
    }

    public function toggle(Product $product)
    {
        $userId = auth()->id();

        $existing = Wishlist::where('user_id', $userId)
            ->where('product_id', $product->id)
            ->first();

        if ($existing) {
            $existing->delete();
            $message = 'Removed from wishlist.';
            $inWishlist = false;
        } else {
            Wishlist::create(['user_id' => $userId, 'product_id' => $product->id]);
            $message = 'Added to wishlist!';
            $inWishlist = true;
        }

        if (request()->expectsJson()) {
            return response()->json(['in_wishlist' => $inWishlist, 'message' => $message]);
        }

        return redirect()->back()->with('success', $message);
    }
}
