<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class Article extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'user_id','category_id','title','slug','body',
        'status','rejection_reason','reviewed_by','reviewed_at',
        'recommend_count','view_count',
    ];

    protected $casts = [
        'reviewed_at'     => 'datetime',
        'recommend_count' => 'integer',
        'view_count'      => 'integer',
    ];

    protected static function boot()
    {
        parent::boot();
        static::creating(function (Article $a) {
            if (empty($a->slug)) {
                $a->slug = Str::slug($a->title) . '-' . Str::random(5);
            }
        });
    }

    // ── Relationships ──────────────────────────────────────────────────
    public function user()            { return $this->belongsTo(User::class); }
    public function category()        { return $this->belongsTo(Category::class); }
    public function reviewer()        { return $this->belongsTo(User::class, 'reviewed_by'); }
    public function comments()        { return $this->hasMany(Comment::class); }
    public function approvedComments(){ return $this->hasMany(Comment::class)->where('status','approved')->latest(); }
    public function recommendations() { return $this->hasMany(ArticleRecommendation::class); }
    public function tags()            { return $this->belongsToMany(Tag::class, 'article_tag'); }

    // ── Scopes ─────────────────────────────────────────────────────────
    public function scopeApproved($q) { return $q->where('status','approved'); }
    public function scopePending($q)  { return $q->where('status','pending'); }
    public function scopeRejected($q) { return $q->where('status','rejected'); }

    // ── Helpers ────────────────────────────────────────────────────────
    public function isApproved(): bool { return $this->status === 'approved'; }
    public function isPending(): bool  { return $this->status === 'pending'; }
    public function isRejected(): bool { return $this->status === 'rejected'; }

    public function isRecommendedBy(User $user): bool
    {
        return $this->recommendations()->where('user_id', $user->id)->exists();
    }

    /** Increment view count (skip for the article's own author) */
    public function incrementView(?int $userId = null): void
    {
        if ($userId && $this->user_id === $userId) return;
        $this->increment('view_count');
    }

    /** Get related articles: same category, excluding self, approved */
    public function related(int $limit = 3)
    {
        return static::approved()
            ->where('category_id', $this->category_id)
            ->where('id', '!=', $this->id)
            ->orderByDesc('recommend_count')
            ->take($limit)
            ->get();
    }
}
