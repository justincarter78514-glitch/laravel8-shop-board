<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Coupon extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'code','description','type','value',
        'min_order_amount','max_discount',
        'usage_limit','usage_count','per_user_limit',
        'is_active','starts_at','expires_at',
    ];

    protected $casts = [
        'value'            => 'decimal:2',
        'min_order_amount' => 'decimal:2',
        'max_discount'     => 'decimal:2',
        'is_active'        => 'boolean',
        'starts_at'        => 'datetime',
        'expires_at'       => 'datetime',
    ];

    public function usages() { return $this->hasMany(CouponUsage::class); }

    public function scopeActive($q)
    {
        return $q->where('is_active', true)
            ->where(fn($q) => $q->whereNull('starts_at')->orWhere('starts_at', '<=', now()))
            ->where(fn($q) => $q->whereNull('expires_at')->orWhere('expires_at', '>=', now()));
    }

    /** Calculate discount amount for a given subtotal. */
    public function calculateDiscount(float $subtotal): float
    {
        if ($this->type === 'percent') {
            $discount = $subtotal * ($this->value / 100);
            if ($this->max_discount) {
                $discount = min($discount, (float) $this->max_discount);
            }
        } else {
            $discount = (float) $this->value;
        }

        return min($discount, $subtotal);
    }

    /** Check if a user can use this coupon. Returns error string or null. */
    public function validateForUser(int $userId, float $subtotal): ?string
    {
        if (!$this->is_active)                         return 'This coupon is inactive.';
        if ($this->starts_at && $this->starts_at > now()) return 'This coupon is not yet valid.';
        if ($this->expires_at && $this->expires_at < now()) return 'This coupon has expired.';
        if ($subtotal < $this->min_order_amount)        return "Minimum order of ₩" . number_format($this->min_order_amount) . " required.";
        if ($this->usage_limit && $this->usage_count >= $this->usage_limit) return 'This coupon has reached its usage limit.';

        $userUsages = $this->usages()->where('user_id', $userId)->count();
        if ($userUsages >= $this->per_user_limit)       return 'You have already used this coupon.';

        return null;
    }

    public function isExpired(): bool
    {
        return $this->expires_at && $this->expires_at->isPast();
    }
}
