<?php

namespace App\Mail;

use App\Models\Product;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class LowStockAlert extends Mailable
{
    use Queueable, SerializesModels;

    public Product $product;
    public int $threshold;

    public function __construct(Product $product, int $threshold = 5)
    {
        $this->product   = $product;
        $this->threshold = $threshold;
    }

    public function build(): static
    {
        return $this->subject('⚠️ Low Stock Alert: ' . $this->product->name)
                    ->view('emails.low-stock');
    }
}
