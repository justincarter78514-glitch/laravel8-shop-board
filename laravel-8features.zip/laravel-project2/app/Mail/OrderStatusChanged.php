<?php

namespace App\Mail;

use App\Models\Order;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class OrderStatusChanged extends Mailable
{
    use Queueable, SerializesModels;

    public Order $order;
    public string $previousStatus;

    public function __construct(Order $order, string $previousStatus)
    {
        $this->order          = $order;
        $this->previousStatus = $previousStatus;
    }

    public function build(): static
    {
        $subject = match($this->order->status) {
            'paid'       => 'Payment Confirmed — Order ' . $this->order->order_number,
            'processing' => 'Your Order is Being Prepared — ' . $this->order->order_number,
            'shipped'    => 'Your Order Has Shipped — ' . $this->order->order_number,
            'delivered'  => 'Order Delivered — ' . $this->order->order_number,
            'cancelled'  => 'Order Cancelled — ' . $this->order->order_number,
            'refunded'   => 'Refund Processed — ' . $this->order->order_number,
            default      => 'Order Update — ' . $this->order->order_number,
        };

        return $this->subject($subject)
                    ->view('emails.order-status');
    }
}
