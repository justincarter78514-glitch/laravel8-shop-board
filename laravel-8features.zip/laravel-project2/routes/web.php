<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\SearchController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\User\ArticleController;
use App\Http\Controllers\User\CommentController;
use App\Http\Controllers\User\ProfileController;
use App\Http\Controllers\User\NotificationController     as UserNotificationController;
use App\Http\Controllers\User\ProductReviewController;
use App\Http\Controllers\Shop\ProductController          as ShopProductController;
use App\Http\Controllers\Shop\CartController;
use App\Http\Controllers\Shop\CheckoutController;
use App\Http\Controllers\Shop\OrderController            as UserOrderController;
use App\Http\Controllers\Admin\AuthController            as AdminAuthController;
use App\Http\Controllers\Admin\CategoryController        as AdminCategoryController;
use App\Http\Controllers\Admin\ArticleController         as AdminArticleController;
use App\Http\Controllers\Admin\CommentController         as AdminCommentController;
use App\Http\Controllers\Admin\InstantReplyController    as AdminInstantReplyController;
use App\Http\Controllers\Admin\UserController            as AdminUserController;
use App\Http\Controllers\Admin\ProductCategoryController as AdminProductCategoryController;
use App\Http\Controllers\Admin\ProductController         as AdminProductController;
use App\Http\Controllers\Admin\OrderController           as AdminOrderController;
use App\Http\Controllers\Admin\NotificationController    as AdminNotificationController;
use App\Http\Controllers\Admin\AboutController           as AdminAboutController;
use App\Http\Controllers\Admin\FaqController             as AdminFaqController;
use App\Http\Controllers\Admin\HeroSlideController;
use App\Http\Controllers\Admin\ProductReviewController   as AdminReviewController;

// ── Home ──────────────────────────────────────────────────────────────────────
Route::get('/', fn() => view('home'))->name('home');

// ── User Auth ─────────────────────────────────────────────────────────────────
Auth::routes(['verify' => true]);

// ── Static pages ─────────────────────────────────────────────────────────────
Route::get('/search', SearchController::class)->name('search');
Route::get('/about',  [PageController::class, 'about'])->name('about');
Route::get('/faq',    [PageController::class, 'faq'])->name('faq');

// ── Profile ───────────────────────────────────────────────────────────────────
Route::prefix('profile')->name('profile.')->middleware(['auth','active'])->group(function () {
    Route::get('/',         [ProfileController::class, 'show'])->name('show');
    Route::get('/edit',     [ProfileController::class, 'edit'])->name('edit');
    Route::put('/',         [ProfileController::class, 'update'])->name('update');
    Route::put('/password', [ProfileController::class, 'changePassword'])->name('password');
    Route::post('/avatar',  [ProfileController::class, 'updateAvatar'])->name('avatar');
});

// ── User Notifications ────────────────────────────────────────────────────────
Route::prefix('notifications')->name('notifications.')->middleware(['auth','active'])->group(function () {
    Route::get('/',                     [UserNotificationController::class, 'index'])->name('index');
    Route::post('/{notification}/read', [UserNotificationController::class, 'markRead'])->name('read');
    Route::post('/read-all',            [UserNotificationController::class, 'markAllRead'])->name('readAll');
});

// ── Product Reviews ───────────────────────────────────────────────────────────
Route::middleware(['auth','active'])->group(function () {
    Route::post('/products/{product}/reviews',  [ProductReviewController::class, 'store'])->name('reviews.store');
    Route::delete('/products/reviews/{review}', [ProductReviewController::class, 'destroy'])->name('reviews.destroy');
});

// ── Bulletin Board ────────────────────────────────────────────────────────────
Route::prefix('board')->name('articles.')->group(function () {
    // Public: article list only
    Route::get('/', [ArticleController::class, 'index'])->name('index');

    // Auth required: everything else (view detail, submit, interact)
    Route::middleware(['auth','active'])->group(function () {
        Route::get('/my-articles', [ArticleController::class, 'myArticles'])->name('my');
        Route::get('/submit',      [ArticleController::class, 'create'])->name('create');
        Route::post('/',           [ArticleController::class, 'store'])->name('store');

        // Article detail — login required to read full article
        Route::get('/{article:slug}', [ArticleController::class, 'show'])->name('show');

        Route::post('/{article}/recommend',       [ArticleController::class, 'recommend'])->name('recommend');
        Route::post('/{article}/comments',        [CommentController::class, 'store'])->name('comments.store');
        Route::post('/{article}/instant-replies', [CommentController::class, 'storeInstant'])->name('instant-replies.store');
    });
});

// ── Shop ──────────────────────────────────────────────────────────────────────
Route::prefix('shop')->name('shop.')->group(function () {
    Route::get('/',               [ShopProductController::class, 'index'])->name('index');
    Route::get('/{product:slug}', [ShopProductController::class, 'show'])->name('show');
});

Route::prefix('cart')->name('cart.')->group(function () {
    // Public: view cart contents
    Route::get('/', [CartController::class, 'index'])->name('index');

    // Auth required: add / modify / remove items
    Route::middleware(['auth','active'])->group(function () {
        Route::post('/add/{product}',       [CartController::class, 'add'])->name('add');
        Route::patch('/update/{cartItem}',  [CartController::class, 'update'])->name('update');
        Route::delete('/remove/{cartItem}', [CartController::class, 'remove'])->name('remove');
        Route::delete('/clear',             [CartController::class, 'clear'])->name('clear');
    });
});

Route::middleware(['auth','active'])->group(function () {
    Route::prefix('checkout')->name('checkout.')->group(function () {
        Route::get('/',  [CheckoutController::class, 'index'])->name('index');
        Route::post('/', [CheckoutController::class, 'store'])->name('store');
    });
    Route::get('/order-confirmation', [CheckoutController::class, 'confirmation'])->name('orders.confirmation');
    Route::prefix('orders')->name('orders.')->group(function () {
        Route::get('/',        [UserOrderController::class, 'index'])->name('index');
        Route::get('/{order}', [UserOrderController::class, 'show'])->name('show');
    });
});

/*
|=============================================================================
| ADMIN PANEL — Role-based access control
|
| Roles & what they can do:
|
| Administrator (is_admin = true)
|   → Everything. All routes accessible.
|
| Moderator (is_admin = false, admin_permissions = [...])
|   → Only routes protected by their granted permissions:
|     approve_articles       → Articles moderation
|     approve_comments       → Comments moderation
|     manage_categories      → Article categories CRUD
|     manage_instant_replies → Instant replies CRUD
|     manage_products        → Products, product categories, reviews
|     manage_orders          → Orders management
|   → Dashboard always accessible to any admin-level user.
|   → Cannot access: Users, Notifications, Hero Slides, About, FAQ
|     (those require full 'admin' middleware).
|
| Regular User (no permissions)
|   → Cannot access /admin at all. Redirected to /admin/login.
|=============================================================================
*/

// ── Admin Login / Logout (public — no middleware) ─────────────────────────────
Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('/login',   [AdminAuthController::class, 'showLogin'])->name('login')->middleware('guest');
    Route::post('/login',  [AdminAuthController::class, 'login'])->name('login.submit')->middleware('guest');
    Route::post('/logout', [AdminAuthController::class, 'logout'])->name('logout');
});

// ── Admin Panel (requires admin.access = full admin OR any partial admin) ─────
Route::prefix('admin')->name('admin.')->middleware('admin.access')->group(function () {

    Route::get('/', fn() => view('admin.dashboard'))->name('dashboard');

    // Article categories — requires manage_categories permission
    Route::prefix('categories')->name('categories.')->middleware('can.admin:manage_categories')->group(function () {
        Route::get('/',                [AdminCategoryController::class, 'index'])->name('index');
        Route::get('/create',          [AdminCategoryController::class, 'create'])->name('create');
        Route::post('/',               [AdminCategoryController::class, 'store'])->name('store');
        Route::get('/{category}/edit', [AdminCategoryController::class, 'edit'])->name('edit');
        Route::put('/{category}',      [AdminCategoryController::class, 'update'])->name('update');
        Route::delete('/{category}',   [AdminCategoryController::class, 'destroy'])->name('destroy');
        Route::post('/{id}/restore',   [AdminCategoryController::class, 'restore'])->name('restore');
    });

    // Articles — requires approve_articles permission
    Route::prefix('articles')->name('articles.')->middleware('can.admin:approve_articles')->group(function () {
        Route::get('/',                   [AdminArticleController::class, 'index'])->name('index');
        Route::get('/{article}',          [AdminArticleController::class, 'show'])->name('show');
        Route::post('/{article}/approve', [AdminArticleController::class, 'approve'])->name('approve');
        Route::post('/{article}/reject',  [AdminArticleController::class, 'reject'])->name('reject');
        Route::delete('/{article}',       [AdminArticleController::class, 'destroy'])->name('destroy')->middleware('admin');
    });

    // Comments — requires approve_comments permission
    Route::prefix('comments')->name('comments.')->middleware('can.admin:approve_comments')->group(function () {
        Route::get('/',                   [AdminCommentController::class, 'index'])->name('index');
        Route::post('/{comment}/approve', [AdminCommentController::class, 'approve'])->name('approve');
        Route::post('/{comment}/reject',  [AdminCommentController::class, 'reject'])->name('reject');
        Route::delete('/{comment}',       [AdminCommentController::class, 'destroy'])->name('destroy');
    });

    // Instant Replies — requires manage_instant_replies permission
    Route::prefix('instant-replies')->name('instant-replies.')->middleware('can.admin:manage_instant_replies')->group(function () {
        Route::get('/',                    [AdminInstantReplyController::class, 'index'])->name('index');
        Route::get('/create',              [AdminInstantReplyController::class, 'create'])->name('create');
        Route::post('/',                   [AdminInstantReplyController::class, 'store'])->name('store');
        Route::get('/{instantReply}/edit', [AdminInstantReplyController::class, 'edit'])->name('edit');
        Route::put('/{instantReply}',      [AdminInstantReplyController::class, 'update'])->name('update');
        Route::delete('/{instantReply}',   [AdminInstantReplyController::class, 'destroy'])->name('destroy');
        Route::post('/{id}/restore',       [AdminInstantReplyController::class, 'restore'])->name('restore');
    });

    // Users — full admin only
    Route::prefix('users')->name('users.')->middleware('admin')->group(function () {
        Route::get('/',              [AdminUserController::class, 'index'])->name('index');
        Route::get('/{user}',        [AdminUserController::class, 'show'])->name('show');
        Route::get('/{user}/edit',   [AdminUserController::class, 'edit'])->name('edit');
        Route::put('/{user}',        [AdminUserController::class, 'update'])->name('update');
        Route::delete('/{user}',     [AdminUserController::class, 'destroy'])->name('destroy');
        Route::post('/{id}/restore', [AdminUserController::class, 'restore'])->name('restore');
    });

    // Product Categories — requires manage_products permission
    Route::prefix('product-categories')->name('product-categories.')->middleware('can.admin:manage_products')->group(function () {
        Route::get('/',                       [AdminProductCategoryController::class, 'index'])->name('index');
        Route::get('/create',                 [AdminProductCategoryController::class, 'create'])->name('create');
        Route::post('/',                      [AdminProductCategoryController::class, 'store'])->name('store');
        Route::get('/{productCategory}/edit', [AdminProductCategoryController::class, 'edit'])->name('edit');
        Route::put('/{productCategory}',      [AdminProductCategoryController::class, 'update'])->name('update');
        Route::delete('/{productCategory}',   [AdminProductCategoryController::class, 'destroy'])->name('destroy');
        Route::post('/{id}/restore',          [AdminProductCategoryController::class, 'restore'])->name('restore');
    });

    // Products — requires manage_products permission
    Route::prefix('products')->name('products.')->middleware('can.admin:manage_products')->group(function () {
        Route::get('/',                   [AdminProductController::class, 'index'])->name('index');
        Route::get('/create',             [AdminProductController::class, 'create'])->name('create');
        Route::post('/',                  [AdminProductController::class, 'store'])->name('store');
        Route::get('/{product}/edit',     [AdminProductController::class, 'edit'])->name('edit');
        Route::put('/{product}',          [AdminProductController::class, 'update'])->name('update');
        Route::delete('/{product}',       [AdminProductController::class, 'destroy'])->name('destroy');
        Route::post('/{id}/restore',      [AdminProductController::class, 'restore'])->name('restore');
        Route::delete('/{product}/images',[AdminProductController::class, 'deleteImage'])->name('image.delete');
    });

    // Product Reviews — requires manage_products permission
    Route::prefix('reviews')->name('reviews.')->middleware('can.admin:manage_products')->group(function () {
        Route::get('/',                  [AdminReviewController::class, 'index'])->name('index');
        Route::post('/{review}/approve', [AdminReviewController::class, 'approve'])->name('approve');
        Route::post('/{review}/reject',  [AdminReviewController::class, 'reject'])->name('reject');
        Route::delete('/{review}',       [AdminReviewController::class, 'destroy'])->name('destroy');
    });

    // Orders — requires manage_orders permission
    Route::prefix('orders')->name('orders.')->middleware('can.admin:manage_orders')->group(function () {
        Route::get('/',                 [AdminOrderController::class, 'index'])->name('index');
        Route::get('/{order}',          [AdminOrderController::class, 'show'])->name('show');
        Route::patch('/{order}/status', [AdminOrderController::class, 'updateStatus'])->name('status');
    });

    // Notifications — full admin only
    Route::prefix('notifications')->name('notifications.')->middleware('admin')->group(function () {
        Route::get('/',                        [AdminNotificationController::class, 'index'])->name('index');
        Route::get('/create',                  [AdminNotificationController::class, 'create'])->name('create');
        Route::post('/',                       [AdminNotificationController::class, 'store'])->name('store');
        Route::get('/{notification}/edit',     [AdminNotificationController::class, 'edit'])->name('edit');
        Route::put('/{notification}',          [AdminNotificationController::class, 'update'])->name('update');
        Route::delete('/{notification}',       [AdminNotificationController::class, 'destroy'])->name('destroy');
        Route::post('/{id}/restore',           [AdminNotificationController::class, 'restore'])->name('restore');
        Route::patch('/{notification}/toggle', [AdminNotificationController::class, 'toggle'])->name('toggle');
    });

    // Hero Slides — full admin only
    Route::prefix('hero-slides')->name('hero-slides.')->middleware('admin')->group(function () {
        Route::get('/',                 [HeroSlideController::class, 'index'])->name('index');
        Route::get('/create',           [HeroSlideController::class, 'create'])->name('create');
        Route::post('/',                [HeroSlideController::class, 'store'])->name('store');
        Route::get('/{heroSlide}/edit', [HeroSlideController::class, 'edit'])->name('edit');
        Route::put('/{heroSlide}',      [HeroSlideController::class, 'update'])->name('update');
        Route::delete('/{heroSlide}',   [HeroSlideController::class, 'destroy'])->name('destroy');
        Route::post('/{id}/restore',    [HeroSlideController::class, 'restore'])->name('restore');
        Route::post('/reorder',         [HeroSlideController::class, 'reorder'])->name('reorder');
    });

    // About Us — full admin only
    Route::prefix('about')->name('about.')->middleware('admin')->group(function () {
        Route::get('/edit',    [AdminAboutController::class, 'edit'])->name('edit');
        Route::put('/',        [AdminAboutController::class, 'update'])->name('update');
        Route::post('/logo',   [AdminAboutController::class, 'uploadLogo'])->name('logo');
        Route::delete('/logo', [AdminAboutController::class, 'removeLogo'])->name('logo.remove');
    });

    // FAQ — full admin only
    Route::prefix('faq')->name('faq.')->middleware('admin')->group(function () {
        Route::get('/',              [AdminFaqController::class, 'index'])->name('index');
        Route::get('/create',        [AdminFaqController::class, 'create'])->name('create');
        Route::post('/',             [AdminFaqController::class, 'store'])->name('store');
        Route::get('/{faq}/edit',    [AdminFaqController::class, 'edit'])->name('edit');
        Route::put('/{faq}',         [AdminFaqController::class, 'update'])->name('update');
        Route::delete('/{faq}',      [AdminFaqController::class, 'destroy'])->name('destroy');
        Route::post('/{id}/restore', [AdminFaqController::class, 'restore'])->name('restore');
    });
});

// ── Wishlist ──────────────────────────────────────────────────────────────────
Route::middleware(['auth','active'])->group(function () {
    Route::get('/wishlist',                  [\App\Http\Controllers\User\WishlistController::class, 'index'])->name('wishlist.index');
    Route::post('/wishlist/{product}/toggle',[\App\Http\Controllers\User\WishlistController::class, 'toggle'])->name('wishlist.toggle');
});

// ── Coupon (AJAX from checkout) ───────────────────────────────────────────────
Route::middleware(['auth','active'])->group(function () {
    Route::post('/coupon/apply',  [\App\Http\Controllers\Shop\CouponController::class, 'apply'])->name('coupon.apply');
    Route::post('/coupon/remove', [\App\Http\Controllers\Shop\CouponController::class, 'remove'])->name('coupon.remove');
});

// Add inside admin group (already has admin.access middleware):
// ── Admin Coupons ─────────────────────────────────────────────────────────────
Route::prefix('admin/coupons')->name('admin.coupons.')->middleware(['admin.access','admin'])->group(function () {
    Route::get('/',              [\App\Http\Controllers\Admin\CouponController::class, 'index'])->name('index');
    Route::get('/create',        [\App\Http\Controllers\Admin\CouponController::class, 'create'])->name('create');
    Route::post('/',             [\App\Http\Controllers\Admin\CouponController::class, 'store'])->name('store');
    Route::get('/{coupon}/edit', [\App\Http\Controllers\Admin\CouponController::class, 'edit'])->name('edit');
    Route::put('/{coupon}',      [\App\Http\Controllers\Admin\CouponController::class, 'update'])->name('update');
    Route::delete('/{coupon}',   [\App\Http\Controllers\Admin\CouponController::class, 'destroy'])->name('destroy');
    Route::post('/{id}/restore', [\App\Http\Controllers\Admin\CouponController::class, 'restore'])->name('restore');
});

// ── Admin bulk actions ────────────────────────────────────────────────────────
Route::middleware(['admin.access','can.admin:approve_articles'])->group(function () {
    Route::post('/admin/articles/bulk', [\App\Http\Controllers\Admin\ArticleController::class, 'bulkAction'])->name('admin.articles.bulk');
});
Route::middleware(['admin.access','can.admin:approve_comments'])->group(function () {
    Route::post('/admin/comments/bulk', [\App\Http\Controllers\Admin\CommentController::class, 'bulkAction'])->name('admin.comments.bulk');
});
