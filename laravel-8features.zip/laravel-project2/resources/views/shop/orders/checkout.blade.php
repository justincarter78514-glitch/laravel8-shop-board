@extends('layouts.app')
@section('title', 'Checkout')

@section('content')
<h4 class="mb-4 fw-bold"><i class="bi bi-bag-check me-2"></i>Checkout</h4>

<div class="row g-4">
    <div class="col-lg-7">
        <div class="card border-0 shadow-sm mb-4" style="border-radius:14px!important;">
            <div class="card-header bg-white fw-semibold border-0 pt-4 pb-2 px-4">Shipping Information</div>
            <div class="card-body px-4 pb-4">
                <form method="POST" action="{{ route('checkout.store') }}" id="checkoutForm">
                @csrf
                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold small">Full Name <span class="text-danger">*</span></label>
                        <input type="text" name="shipping_name" class="form-control @error('shipping_name') is-invalid @enderror"
                               value="{{ old('shipping_name', auth()->user()->name) }}" required>
                        @error('shipping_name')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold small">Email <span class="text-danger">*</span></label>
                        <input type="email" name="shipping_email" class="form-control @error('shipping_email') is-invalid @enderror"
                               value="{{ old('shipping_email', auth()->user()->email) }}" required>
                        @error('shipping_email')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                </div>
                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold small">Phone</label>
                        <input type="text" name="shipping_phone" class="form-control"
                               value="{{ old('shipping_phone', auth()->user()->phone) }}">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold small">Country <span class="text-danger">*</span></label>
                        <select name="shipping_country" class="form-select" required>
                            <option value="KR" {{ old('shipping_country','KR')==='KR' ? 'selected':'' }}>South Korea</option>
                            <option value="US" {{ old('shipping_country')==='US' ? 'selected':'' }}>United States</option>
                            <option value="JP" {{ old('shipping_country')==='JP' ? 'selected':'' }}>Japan</option>
                        </select>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold small">Address <span class="text-danger">*</span></label>
                    <input type="text" name="shipping_address" class="form-control @error('shipping_address') is-invalid @enderror"
                           value="{{ old('shipping_address', auth()->user()->address) }}" required>
                    @error('shipping_address')<div class="invalid-feedback">{{ $message }}</div>@enderror
                </div>
                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold small">City <span class="text-danger">*</span></label>
                        <input type="text" name="shipping_city" class="form-control @error('shipping_city') is-invalid @enderror"
                               value="{{ old('shipping_city') }}" required>
                        @error('shipping_city')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold small">ZIP Code <span class="text-danger">*</span></label>
                        <input type="text" name="shipping_zip" class="form-control @error('shipping_zip') is-invalid @enderror"
                               value="{{ old('shipping_zip') }}" required>
                        @error('shipping_zip')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                </div>

                <hr class="my-4">
                <h6 class="fw-semibold mb-3">Payment Method</h6>
                @foreach(['card'=>'Credit / Debit Card','bank_transfer'=>'Bank Transfer','cash_on_delivery'=>'Cash on Delivery'] as $val=>$label)
                <div class="form-check mb-2">
                    <input class="form-check-input" type="radio" name="payment_method"
                           id="pay_{{ $val }}" value="{{ $val }}"
                           {{ old('payment_method','card')===$val ? 'checked':'' }} required>
                    <label class="form-check-label" for="pay_{{ $val }}">{{ $label }}</label>
                </div>
                @endforeach

                <div class="mt-3">
                    <label class="form-label fw-semibold small">Order Notes (optional)</label>
                    <textarea name="notes" class="form-control" rows="2">{{ old('notes') }}</textarea>
                </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-5">
        {{-- Coupon --}}
        <div class="card border-0 shadow-sm mb-3" style="border-radius:14px!important;">
            <div class="card-header bg-white fw-semibold border-0 pt-3 pb-2 px-4">
                <i class="bi bi-ticket-perforated me-2"></i>Coupon Code
            </div>
            <div class="card-body px-4 pb-4">
                @if($couponCode)
                <div class="alert alert-success border-0 small d-flex justify-content-between align-items-center mb-0"
                     style="border-radius:10px!important;">
                    <span><i class="bi bi-check-circle me-1"></i><strong>{{ $couponCode }}</strong> applied! Saving ₩{{ number_format($discount) }}</span>
                    <button class="btn btn-sm btn-outline-danger" onclick="removeCoupon()">Remove</button>
                </div>
                @else
                <div class="input-group">
                    <input type="text" id="couponInput" class="form-control text-uppercase"
                           placeholder="Enter coupon code…" style="letter-spacing:1px;">
                    <button class="btn btn-outline-primary" onclick="applyCoupon()">Apply</button>
                </div>
                <div id="couponMsg" class="small mt-2"></div>
                @endif
            </div>
        </div>

        {{-- Order summary --}}
        <div class="card border-0 shadow-sm" style="border-radius:14px!important;">
            <div class="card-header bg-white fw-semibold border-0 pt-3 pb-2 px-4">Order Summary</div>
            <div class="list-group list-group-flush">
                @foreach($items as $item)
                <div class="list-group-item d-flex justify-content-between align-items-center px-4 py-2 small">
                    <span>{{ $item->product->name }} × {{ $item->quantity }}</span>
                    <span>₩{{ number_format($item->product->currentPrice() * $item->quantity) }}</span>
                </div>
                @endforeach
            </div>
            <div class="card-body px-4 pb-2">
                <div class="d-flex justify-content-between mb-1 small text-muted">
                    <span>Subtotal</span><span>₩{{ number_format($subtotal) }}</span>
                </div>
                <div class="d-flex justify-content-between mb-1 small text-muted">
                    <span>Shipping</span><span>₩3,000</span>
                </div>
                @if($discount > 0)
                <div class="d-flex justify-content-between mb-1 small text-success fw-semibold">
                    <span><i class="bi bi-ticket me-1"></i>Coupon ({{ $couponCode }})</span>
                    <span>-₩{{ number_format($discount) }}</span>
                </div>
                @endif
                <hr class="my-2">
                <div class="d-flex justify-content-between fw-bold">
                    <span>Total</span>
                    <span class="text-primary fs-5">₩{{ number_format(max(0,$subtotal+3000-$discount)) }}</span>
                </div>
            </div>
            <div class="card-footer bg-white border-0 px-4 pb-4">
                <button type="submit" form="checkoutForm" class="btn btn-primary w-100 py-2 fw-bold">
                    <i class="bi bi-lock me-2"></i>Place Order
                </button>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
function applyCoupon() {
    const code = document.getElementById('couponInput').value.trim().toUpperCase();
    const msg  = document.getElementById('couponMsg');
    if (!code) return;

    fetch('{{ route("coupon.apply") }}', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
        body: JSON.stringify({ code })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            msg.innerHTML = `<span class="text-success"><i class="bi bi-check-circle me-1"></i>${data.message}</span>`;
            setTimeout(() => location.reload(), 800);
        } else {
            msg.innerHTML = `<span class="text-danger"><i class="bi bi-x-circle me-1"></i>${data.message}</span>`;
        }
    })
    .catch(() => { msg.innerHTML = '<span class="text-danger">Something went wrong.</span>'; });
}

function removeCoupon() {
    fetch('{{ route("coupon.remove") }}', {
        method: 'POST',
        headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' }
    }).then(() => location.reload());
}

document.getElementById('couponInput')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') { e.preventDefault(); applyCoupon(); }
});
</script>
@endpush
