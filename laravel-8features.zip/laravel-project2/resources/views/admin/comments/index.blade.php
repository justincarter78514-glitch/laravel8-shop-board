@extends('layouts.admin')
@section('title', 'Comment Moderation')

@section('content')
<h5 class="mb-4">Comment Moderation</h5>

<ul class="nav nav-tabs mb-4">
    @foreach(['pending'=>'warning','approved'=>'success','rejected'=>'danger'] as $s=>$color)
    <li class="nav-item">
        <a class="nav-link {{ $status===$s?'active':'' }}" href="{{ route('admin.comments.index',['status'=>$s]) }}">
            {{ ucfirst($s) }} <span class="badge bg-{{ $color }} ms-1">{{ $counts[$s] }}</span>
        </a>
    </li>
    @endforeach
</ul>

<form id="bulkForm" method="POST" action="{{ route('admin.comments.bulk') }}">
@csrf

<div class="d-flex align-items-center gap-2 mb-3 p-3 bg-light rounded" id="bulkBar" style="display:none!important;">
    <span class="small fw-semibold text-muted" id="selectedCount">0 selected</span>
    <button type="submit" name="action" value="approve" class="btn btn-sm btn-success">
        <i class="bi bi-check-all me-1"></i>Approve Selected
    </button>
    <button type="button" class="btn btn-sm btn-danger" onclick="submitBulkReject()">
        <i class="bi bi-x-circle me-1"></i>Reject Selected
    </button>
</div>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th style="width:36px;">
                        <input type="checkbox" id="selectAll" class="form-check-input" onchange="toggleAll(this)">
                    </th>
                    <th>Comment</th><th>Author</th><th>Article</th><th>Date</th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($comments as $comment)
                <tr>
                    <td><input type="checkbox" name="ids[]" value="{{ $comment->id }}" class="form-check-input row-check" onchange="updateBulkBar()"></td>
                    <td>{{ Str::limit($comment->body,80) }}</td>
                    <td>{{ $comment->user->name }}</td>
                    <td>
                        <a href="{{ route('admin.articles.show',$comment->article) }}" class="text-decoration-none small">
                            {{ Str::limit($comment->article->title,40) }}
                        </a>
                    </td>
                    <td class="text-muted small">{{ $comment->created_at->format('Y-m-d') }}</td>
                    <td>
                        @if($comment->isPending())
                        <form method="POST" action="{{ route('admin.comments.approve',$comment) }}" class="d-inline">
                            @csrf <button class="btn btn-sm btn-success">Approve</button>
                        </form>
                        <button class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#rejectModal"
                                data-action="{{ route('admin.comments.reject',$comment) }}"
                                data-body="{{ Str::limit($comment->body,100) }}">Reject</button>
                        @endif
                        <form method="POST" action="{{ route('admin.comments.destroy',$comment) }}" class="d-inline"
                              onsubmit="return confirm('Delete this comment?')">
                            @csrf @method('DELETE')
                            <button class="btn btn-sm btn-outline-danger">Delete</button>
                        </form>
                    </td>
                </tr>
                @empty
                <tr><td colspan="6" class="text-center text-muted py-4">No {{ $status }} comments.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    @if($comments->hasPages())
    <div class="card-footer bg-white">{{ $comments->withQueryString()->links() }}</div>
    @endif
</div>
</form>

<div class="modal fade" id="rejectModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form method="POST" id="rejectForm" class="modal-content">
            @csrf
            <div class="modal-header">
                <h5 class="modal-title">Reject Comment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-light border small mb-3" id="rejectCommentBody"></div>
                <label class="form-label fw-semibold">Rejection Reason <span class="text-danger">*</span></label>
                <textarea name="rejection_reason" class="form-control" rows="2" required></textarea>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-danger">Reject</button>
            </div>
        </form>
    </div>
</div>
@endsection

@push('scripts')
<script>
document.getElementById('rejectModal').addEventListener('show.bs.modal', function(e) {
    const btn = e.relatedTarget;
    document.getElementById('rejectForm').action = btn.dataset.action;
    document.getElementById('rejectCommentBody').textContent = btn.dataset.body;
    document.getElementById('rejectForm').querySelector('textarea').value = '';
});

function toggleAll(cb) {
    document.querySelectorAll('.row-check').forEach(c => c.checked = cb.checked);
    updateBulkBar();
}

function updateBulkBar() {
    const checked = document.querySelectorAll('.row-check:checked').length;
    document.getElementById('bulkBar').style.display = checked > 0 ? 'flex' : 'none';
    document.getElementById('selectedCount').textContent = checked + ' selected';
}

function submitBulkReject() {
    const reason = prompt('Rejection reason for all selected comments:');
    if (!reason) return;
    const form = document.getElementById('bulkForm');
    ['rejection_reason','action'].forEach(n => { let e=form.querySelector(`[name="${n}"]`); if(e) e.remove(); });
    let r=document.createElement('input'); r.type='hidden'; r.name='rejection_reason'; r.value=reason; form.appendChild(r);
    let a=document.createElement('input'); a.type='hidden'; a.name='action'; a.value='reject'; form.appendChild(a);
    form.submit();
}
</script>
@endpush
