@extends('layouts.admin')
@section('title', 'Article Moderation')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h5 class="mb-0">Article Moderation</h5>
</div>

<ul class="nav nav-tabs mb-4">
    @foreach(['pending'=>'warning','approved'=>'success','rejected'=>'danger'] as $s=>$color)
    <li class="nav-item">
        <a class="nav-link {{ $status===$s?'active':'' }}" href="{{ route('admin.articles.index',['status'=>$s]) }}">
            {{ ucfirst($s) }} <span class="badge bg-{{ $color }} ms-1">{{ $counts[$s] }}</span>
        </a>
    </li>
    @endforeach
</ul>

<form id="bulkForm" method="POST" action="{{ route('admin.articles.bulk') }}">
@csrf

{{-- Bulk action bar --}}
<div class="d-flex align-items-center gap-2 mb-3 p-3 bg-light rounded" id="bulkBar" style="display:none!important;">
    <span class="small fw-semibold text-muted" id="selectedCount">0 selected</span>
    <button type="submit" name="action" value="approve" class="btn btn-sm btn-success">
        <i class="bi bi-check-all me-1"></i>Approve Selected
    </button>
    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#bulkRejectModal">
        <i class="bi bi-x-circle me-1"></i>Reject Selected
    </button>
</div>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th style="width:36px;">
                        <input type="checkbox" id="selectAll" class="form-check-input" onchange="toggleAll(this)">
                    </th>
                    <th>Title</th><th>Author</th><th>Category</th><th>Views</th><th>Date</th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($articles as $article)
                <tr>
                    <td>
                        <input type="checkbox" name="ids[]" value="{{ $article->id }}"
                               class="form-check-input row-check" onchange="updateBulkBar()">
                    </td>
                    <td>
                        <a href="{{ route('admin.articles.show',$article) }}" class="text-decoration-none fw-semibold">
                            {{ Str::limit($article->title,60) }}
                        </a>
                        @if($article->rejection_reason)
                        <div class="text-danger small">{{ Str::limit($article->rejection_reason,55) }}</div>
                        @endif
                    </td>
                    <td>{{ $article->user->name }}</td>
                    <td><span class="badge bg-secondary">{{ $article->category->name }}</span></td>
                    <td class="text-muted small"><i class="bi bi-eye me-1"></i>{{ number_format($article->view_count) }}</td>
                    <td class="text-muted small">{{ $article->created_at->format('Y-m-d') }}</td>
                    <td>
                        <a href="{{ route('admin.articles.show',$article) }}" class="btn btn-sm btn-outline-primary">View</a>
                        @if($article->isPending())
                        <form method="POST" action="{{ route('admin.articles.approve',$article) }}" class="d-inline">
                            @csrf <button class="btn btn-sm btn-success">Approve</button>
                        </form>
                        <button class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#rejectModal"
                                data-action="{{ route('admin.articles.reject',$article) }}"
                                data-title="{{ Str::limit($article->title,80) }}">Reject</button>
                        @elseif($article->isApproved())
                        <button class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#rejectModal"
                                data-action="{{ route('admin.articles.reject',$article) }}"
                                data-title="{{ Str::limit($article->title,80) }}">Revoke</button>
                        @endif
                    </td>
                </tr>
                @empty
                <tr><td colspan="7" class="text-center text-muted py-4">No {{ $status }} articles.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    @if($articles->hasPages())
    <div class="card-footer bg-white">{{ $articles->withQueryString()->links() }}</div>
    @endif
</div>
</form>

{{-- Single reject modal --}}
<div class="modal fade" id="rejectModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form method="POST" id="rejectForm" class="modal-content">
            @csrf
            <div class="modal-header">
                <h5 class="modal-title">Reject Article</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-light border small fw-semibold mb-3" id="rejectArticleTitle"></div>
                <label class="form-label fw-semibold">Rejection Reason <span class="text-danger">*</span></label>
                <textarea name="rejection_reason" class="form-control" rows="3" required></textarea>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-danger">Reject</button>
            </div>
        </form>
    </div>
</div>

{{-- Bulk reject modal --}}
<div class="modal fade" id="bulkRejectModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Bulk Reject Articles</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <label class="form-label fw-semibold">Rejection Reason <span class="text-danger">*</span></label>
                <textarea id="bulkRejectReason" class="form-control" rows="3"
                          placeholder="This reason will be applied to all selected articles."></textarea>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" onclick="submitBulkReject()">Reject Selected</button>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
document.getElementById('rejectModal').addEventListener('show.bs.modal', function(e) {
    const btn = e.relatedTarget;
    document.getElementById('rejectForm').action = btn.dataset.action;
    document.getElementById('rejectArticleTitle').textContent = btn.dataset.title;
    document.getElementById('rejectForm').querySelector('textarea').value = '';
});

function toggleAll(cb) {
    document.querySelectorAll('.row-check').forEach(c => c.checked = cb.checked);
    updateBulkBar();
}

function updateBulkBar() {
    const checked = document.querySelectorAll('.row-check:checked').length;
    const bar = document.getElementById('bulkBar');
    bar.style.display = checked > 0 ? 'flex' : 'none';
    document.getElementById('selectedCount').textContent = checked + ' selected';
}

function submitBulkReject() {
    const reason = document.getElementById('bulkRejectReason').value.trim();
    if (!reason) { alert('Please enter a rejection reason.'); return; }

    // Add reason input and action to form, then submit
    const form = document.getElementById('bulkForm');
    let inp = document.createElement('input');
    inp.type='hidden'; inp.name='rejection_reason'; inp.value=reason;
    form.appendChild(inp);

    let act = document.createElement('input');
    act.type='hidden'; act.name='action'; act.value='reject';
    form.appendChild(act);

    bootstrap.Modal.getInstance(document.getElementById('bulkRejectModal')).hide();
    form.submit();
}
</script>
@endpush
