@extends('layouts.admin')
@section('title', isset($coupon) ? 'Edit Coupon' : 'New Coupon')

@section('content')
<div class="row justify-content-center">
<div class="col-lg-7">
<div class="card border-0 shadow-sm">
    <div class="card-header bg-white fw-semibold">{{ isset($coupon) ? 'Edit Coupon: '.$coupon->code : 'Create Coupon' }}</div>
    <div class="card-body p-4">
    <form method="POST" action="{{ isset($coupon) ? route('admin.coupons.update',$coupon) : route('admin.coupons.store') }}">
        @csrf @if(isset($coupon)) @method('PUT') @endif

        <div class="row g-3 mb-3">
            <div class="col-md-6">
                <label class="form-label fw-semibold">Code <span class="text-danger">*</span></label>
                <input type="text" name="code" class="form-control font-monospace text-uppercase @error('code') is-invalid @enderror"
                       value="{{ old('code', $coupon->code ?? '') }}" placeholder="SAVE20" required
                       style="letter-spacing:2px;">
                @error('code')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold">Description</label>
                <input type="text" name="description" class="form-control"
                       value="{{ old('description', $coupon->description ?? '') }}"
                       placeholder="e.g. 20% off all orders">
            </div>
        </div>

        <div class="row g-3 mb-3">
            <div class="col-md-4">
                <label class="form-label fw-semibold">Discount Type <span class="text-danger">*</span></label>
                <select name="type" class="form-select @error('type') is-invalid @enderror" required id="typeSelect" onchange="toggleMaxDiscount()">
                    <option value="percent" {{ old('type',$coupon->type??'percent')==='percent' ? 'selected':'' }}>Percentage (%)</option>
                    <option value="fixed"   {{ old('type',$coupon->type??'')==='fixed'   ? 'selected':'' }}>Fixed Amount (₩)</option>
                </select>
                @error('type')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold">Value <span class="text-danger">*</span></label>
                <div class="input-group">
                    <span class="input-group-text" id="valuePrefix">%</span>
                    <input type="number" name="value" class="form-control @error('value') is-invalid @enderror"
                           value="{{ old('value', $coupon->value ?? '') }}" min="0" step="0.01" required>
                </div>
                @error('value')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="col-md-4" id="maxDiscountBox">
                <label class="form-label fw-semibold">Max Discount (₩)</label>
                <input type="number" name="max_discount" class="form-control"
                       value="{{ old('max_discount', $coupon->max_discount ?? '') }}"
                       min="0" step="1000" placeholder="No cap">
                <div class="form-text">Caps percent discount amount.</div>
            </div>
        </div>

        <div class="row g-3 mb-3">
            <div class="col-md-6">
                <label class="form-label fw-semibold">Minimum Order Amount (₩)</label>
                <input type="number" name="min_order_amount" class="form-control"
                       value="{{ old('min_order_amount', $coupon->min_order_amount ?? 0) }}"
                       min="0" step="1000" placeholder="0 = no minimum">
            </div>
            <div class="col-md-3">
                <label class="form-label fw-semibold">Total Usage Limit</label>
                <input type="number" name="usage_limit" class="form-control"
                       value="{{ old('usage_limit', $coupon->usage_limit ?? '') }}"
                       min="1" placeholder="∞ unlimited">
            </div>
            <div class="col-md-3">
                <label class="form-label fw-semibold">Per User Limit</label>
                <input type="number" name="per_user_limit" class="form-control"
                       value="{{ old('per_user_limit', $coupon->per_user_limit ?? 1) }}"
                       min="1">
            </div>
        </div>

        <div class="row g-3 mb-3">
            <div class="col-md-6">
                <label class="form-label fw-semibold">Valid From</label>
                <input type="datetime-local" name="starts_at" class="form-control"
                       value="{{ old('starts_at', isset($coupon) && $coupon->starts_at ? $coupon->starts_at->format('Y-m-d\TH:i') : '') }}">
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold">Expires At</label>
                <input type="datetime-local" name="expires_at" class="form-control"
                       value="{{ old('expires_at', isset($coupon) && $coupon->expires_at ? $coupon->expires_at->format('Y-m-d\TH:i') : '') }}">
            </div>
        </div>

        <div class="form-check mb-4">
            <input type="checkbox" name="is_active" id="is_active" class="form-check-input" value="1"
                   {{ old('is_active', $coupon->is_active ?? true) ? 'checked':'' }}>
            <label class="form-check-label" for="is_active">Active (usable by customers)</label>
        </div>

        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-primary">{{ isset($coupon) ? 'Save Changes':'Create Coupon' }}</button>
            <a href="{{ route('admin.coupons.index') }}" class="btn btn-outline-secondary">Cancel</a>
        </div>
    </form>
    </div>
</div>
</div>
</div>
@endsection

@push('scripts')
<script>
function toggleMaxDiscount() {
    const type   = document.getElementById('typeSelect').value;
    const box    = document.getElementById('maxDiscountBox');
    const prefix = document.getElementById('valuePrefix');
    box.style.display    = type === 'percent' ? '' : 'none';
    prefix.textContent   = type === 'percent' ? '%' : '₩';
}
toggleMaxDiscount();
</script>
@endpush
