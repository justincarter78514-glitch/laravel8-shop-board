@extends('layouts.admin')
@section('title', 'Coupons')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h5 class="mb-0">Coupon Codes</h5>
    <a href="{{ route('admin.coupons.create') }}" class="btn btn-primary btn-sm">
        <i class="bi bi-plus-circle me-1"></i>New Coupon
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr><th>Code</th><th>Type</th><th>Value</th><th>Min Order</th><th>Usage</th><th>Expires</th><th>Status</th><th>Actions</th></tr>
            </thead>
            <tbody>
                @forelse($coupons as $coupon)
                <tr class="{{ $coupon->trashed() ? 'table-secondary text-muted':'' }}">
                    <td>
                        <span class="fw-bold font-monospace">{{ $coupon->code }}</span>
                        @if($coupon->description)<div class="text-muted small">{{ $coupon->description }}</div>@endif
                    </td>
                    <td>
                        <span class="badge {{ $coupon->type==='percent' ? 'bg-info text-dark':'bg-success' }}">
                            {{ $coupon->type }}
                        </span>
                    </td>
                    <td class="fw-semibold">
                        {{ $coupon->type==='percent' ? $coupon->value.'%' : '₩'.number_format($coupon->value) }}
                        @if($coupon->max_discount)<div class="text-muted small">max ₩{{ number_format($coupon->max_discount) }}</div>@endif
                    </td>
                    <td>{{ $coupon->min_order_amount > 0 ? '₩'.number_format($coupon->min_order_amount) : '—' }}</td>
                    <td>
                        {{ $coupon->usages_count }} / {{ $coupon->usage_limit ?? '∞' }}
                        <div class="text-muted small">{{ $coupon->per_user_limit }}× per user</div>
                    </td>
                    <td>
                        @if($coupon->expires_at)
                            <span class="{{ $coupon->isExpired() ? 'text-danger':'' }} small">
                                {{ $coupon->expires_at->format('Y-m-d') }}
                                @if($coupon->isExpired())<span class="badge bg-danger ms-1">Expired</span>@endif
                            </span>
                        @else <span class="text-muted small">No expiry</span> @endif
                    </td>
                    <td>
                        @if(!$coupon->trashed())
                            <span class="badge bg-{{ $coupon->is_active ? 'success':'secondary' }}">{{ $coupon->is_active ? 'Active':'Inactive' }}</span>
                        @else <span class="badge bg-danger">Deleted</span> @endif
                    </td>
                    <td>
                        @if(!$coupon->trashed())
                            <a href="{{ route('admin.coupons.edit',$coupon) }}" class="btn btn-sm btn-outline-primary">Edit</a>
                            <form method="POST" action="{{ route('admin.coupons.destroy',$coupon) }}" class="d-inline" onsubmit="return confirm('Delete?')">
                                @csrf @method('DELETE')
                                <button class="btn btn-sm btn-outline-danger">Delete</button>
                            </form>
                        @else
                            <form method="POST" action="{{ route('admin.coupons.restore',$coupon->id) }}" class="d-inline">
                                @csrf <button class="btn btn-sm btn-outline-success">Restore</button>
                            </form>
                        @endif
                    </td>
                </tr>
                @empty
                <tr><td colspan="8" class="text-center text-muted py-5">No coupons yet. <a href="{{ route('admin.coupons.create') }}">Create one</a>.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    @if($coupons->hasPages())<div class="card-footer bg-white">{{ $coupons->links() }}</div>@endif
</div>
@endsection
