<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Low Stock Alert</title>
    <style>
        body { font-family:'Segoe UI',Arial,sans-serif; background:#f4f6f9; margin:0; padding:0; }
        .wrapper { max-width:560px; margin:32px auto; }
        .header { background:linear-gradient(135deg,#b45309,#92400e); color:#fff; padding:28px 36px; border-radius:16px 16px 0 0; text-align:center; }
        .body { background:#fff; padding:32px 36px; border-radius:0 0 16px 16px; }
        .alert-box { background:#fffbeb; border:1px solid #fde68a; border-radius:12px; padding:20px; margin:20px 0; display:flex; align-items:center; gap:16px; }
        .btn { display:inline-block; background:#b45309; color:#fff !important; padding:12px 28px; border-radius:10px; text-decoration:none; font-weight:700; font-size:.9rem; margin-top:16px; }
        .footer { text-align:center; color:#94a3b8; font-size:.75rem; margin-top:20px; }
    </style>
</head>
<body>
<div class="wrapper">
    <div class="header">
        <div style="font-size:2.5rem;margin-bottom:6px;">⚠️</div>
        <h1 style="margin:0;font-size:1.3rem;">Low Stock Alert</h1>
    </div>
    <div class="body">
        <p>A product in your store is running low on stock.</p>

        <div class="alert-box">
            <div style="font-size:2rem;">📦</div>
            <div>
                <div style="font-weight:700;font-size:1rem;">{{ $product->name }}</div>
                <div style="color:#92400e;font-size:.85rem;margin-top:4px;">
                    Current stock: <strong>{{ $product->stock }} units</strong>
                    (threshold: {{ $threshold }})
                </div>
                @if($product->sku)
                <div style="color:#64748b;font-size:.78rem;">SKU: {{ $product->sku }}</div>
                @endif
            </div>
        </div>

        <p style="font-size:.88rem;color:#555;">
            Please restock this item soon to avoid disappointing customers.
            You can update the stock level from the admin panel.
        </p>

        <center>
            <a href="{{ url('/admin/products/'.$product->id.'/edit') }}" class="btn">
                Update Stock Now
            </a>
        </center>
    </div>
    <div class="footer">
        <p>{{ config('app.name') }} Admin Notification · {{ now()->format('Y-m-d H:i') }}</p>
    </div>
</div>
</body>
</html>
