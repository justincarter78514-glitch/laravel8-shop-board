<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Order Update</title>
    <style>
        body { font-family:'Segoe UI',Arial,sans-serif; background:#f4f6f9; margin:0; padding:0; color:#333; }
        .wrapper { max-width:600px; margin:32px auto; }
        .header {
            background:linear-gradient(135deg,#2E7D32,#1B5E20);
            color:#fff; padding:32px 40px; border-radius:16px 16px 0 0;
            text-align:center;
        }
        .header-icon { font-size:2.5rem; margin-bottom:8px; }
        .header h1 { margin:0; font-size:1.4rem; font-weight:700; }
        .header p  { margin:6px 0 0; opacity:.75; font-size:.9rem; }
        .body { background:#fff; padding:32px 40px; }
        .status-badge {
            display:inline-block; padding:8px 24px; border-radius:20px;
            font-weight:700; font-size:.9rem; margin:16px 0;
        }
        .table { width:100%; border-collapse:collapse; margin:20px 0; }
        .table th { background:#f8fafc; padding:10px 14px; text-align:left; font-size:.8rem; color:#64748b; font-weight:600; border-bottom:1px solid #e2e8f0; }
        .table td { padding:12px 14px; border-bottom:1px solid #f1f5f9; font-size:.88rem; }
        .total-row td { font-weight:700; font-size:.95rem; border-top:2px solid #e2e8f0; }
        .btn {
            display:inline-block; background:#2E7D32; color:#fff !important;
            padding:13px 32px; border-radius:10px; text-decoration:none;
            font-weight:700; font-size:.9rem; margin-top:20px;
        }
        .footer { text-align:center; padding:20px 40px; color:#94a3b8; font-size:.78rem; border-radius:0 0 16px 16px; background:#f8fafc; }
        .step-row { display:flex; align-items:center; margin:6px 0; }
        .step-dot { width:14px; height:14px; border-radius:50%; margin-right:12px; flex-shrink:0; }
        .step-done { background:#22c55e; }
        .step-current { background:#2E7D32; box-shadow:0 0 0 3px rgba(46,125,50,.2); }
        .step-todo { background:#e2e8f0; }
    </style>
</head>
<body>
<div class="wrapper">

    <div class="header">
        <div class="header-icon">
            @php
                $icon = match($order->status) {
                    'paid'      => '✅','processing'=>'⚙️','shipped'=>'📦',
                    'delivered' => '🎉','cancelled' =>'❌','refunded'  =>'💰',
                    default     => '📋',
                };
            @endphp
            {{ $icon }}
        </div>
        <h1>Order Update</h1>
        <p>{{ $order->order_number }}</p>
    </div>

    <div class="body">
        <p>Hi <strong>{{ $order->shipping_name }}</strong>,</p>
        <p>
            @switch($order->status)
                @case('paid')       Your payment has been confirmed. We're getting your order ready! @break
                @case('processing') Great news — your order is now being prepared for shipment. @break
                @case('shipped')    Your order is on its way! You should receive it soon. @break
                @case('delivered')  Your order has been delivered. We hope you love it! @break
                @case('cancelled')  Your order has been cancelled. If you paid, a refund will follow. @break
                @case('refunded')   Your refund has been processed and should appear within 3–5 business days. @break
                @default            Your order status has been updated. @break
            @endswitch
        </p>

        {{-- Status badge --}}
        @php
            $colors = [
                'paid'=>['#f0fdf4','#166534'],'processing'=>['#eff6ff','#1e40af'],
                'shipped'=>['#f0f9ff','#0c4a6e'],'delivered'=>['#f0fdf4','#166534'],
                'cancelled'=>['#fef2f2','#991b1b'],'refunded'=>['#fdf4ff','#6b21a8'],
            ];
            [$bg,$tc] = $colors[$order->status] ?? ['#f8fafc','#334155'];
        @endphp
        <div>
            <span class="status-badge"
                  style="background:{{ $bg }};color:{{ $tc }};">
                {{ ucfirst($order->status) }}
            </span>
        </div>

        {{-- Order timeline --}}
        <p style="font-weight:600;margin-top:20px;margin-bottom:8px;">Order Progress</p>
        @php
            $steps = ['pending'=>'Order Placed','paid'=>'Payment Confirmed','processing'=>'Being Prepared','shipped'=>'Shipped','delivered'=>'Delivered'];
            $keys  = array_keys($steps);
            $curr  = array_search($order->status, $keys) !== false ? array_search($order->status, $keys) : 0;
        @endphp
        @foreach($steps as $key => $label)
        @php $idx = array_search($key, $keys); @endphp
        <div class="step-row">
            <div class="step-dot {{ $idx < $curr ? 'step-done' : ($idx === $curr ? 'step-current' : 'step-todo') }}"></div>
            <span style="font-size:.85rem;color:{{ $idx <= $curr ? '#1C1C1C' : '#94a3b8' }};{{ $idx === $curr ? 'font-weight:700;' : '' }}">
                {{ $label }}
            </span>
            @if($idx === $curr)
                <span style="font-size:.72rem;background:#dcfce7;color:#166534;padding:2px 8px;border-radius:10px;margin-left:8px;font-weight:700;">Current</span>
            @endif
        </div>
        @endforeach

        {{-- Order items --}}
        <p style="font-weight:600;margin-top:24px;margin-bottom:0;">Order Summary</p>
        <table class="table">
            <thead>
                <tr><th>Item</th><th>Qty</th><th>Subtotal</th></tr>
            </thead>
            <tbody>
                @foreach($order->items as $item)
                <tr>
                    <td>{{ $item->product_name }}</td>
                    <td>{{ $item->quantity }}</td>
                    <td>₩{{ number_format($item->subtotal) }}</td>
                </tr>
                @endforeach
                <tr><td colspan="2" style="text-align:right;color:#64748b;font-size:.82rem;">Shipping</td><td>₩{{ number_format($order->shipping_fee) }}</td></tr>
                @if($order->discount > 0)
                <tr><td colspan="2" style="text-align:right;color:#16a34a;font-size:.82rem;">Discount</td><td style="color:#16a34a;">-₩{{ number_format($order->discount) }}</td></tr>
                @endif
                <tr class="total-row"><td colspan="2" style="text-align:right;">Total</td><td style="color:#2E7D32;">₩{{ number_format($order->total) }}</td></tr>
            </tbody>
        </table>

        {{-- Shipping address --}}
        <p style="font-size:.82rem;color:#64748b;margin-top:16px;">
            <strong>Shipping to:</strong> {{ $order->shipping_name }},
            {{ $order->shipping_address }}, {{ $order->shipping_city }}
        </p>

        <center>
            <a href="{{ url('/orders/'.$order->id) }}" class="btn">View Order Details</a>
        </center>
    </div>

    <div class="footer">
        <p>{{ config('app.name') }} · If you have questions, reply to this email.</p>
        <p style="margin-top:4px;">© {{ date('Y') }} {{ config('app.name') }}. All rights reserved.</p>
    </div>
</div>
</body>
</html>
