@extends('layouts.app')
@section('title', $article->title)

@section('content')
<div class="row justify-content-center">
<div class="col-lg-9">

<div class="card border-0 shadow-sm mb-4" style="border-radius:16px!important;">
    <div class="card-body p-4 p-md-5">
        {{-- Category + Tags --}}
        <div class="mb-3">
            <a href="{{ route('articles.index',['category_id'=>$article->category_id]) }}"
               class="badge bg-secondary text-decoration-none me-1">{{ $article->category->name }}</a>
            @foreach($article->tags as $tag)
            <a href="{{ route('articles.index',['tag'=>$tag->slug]) }}"
               class="badge bg-light text-dark border text-decoration-none me-1" style="font-size:.7rem;">
                #{{ $tag->name }}
            </a>
            @endforeach
        </div>

        <h2 class="fw-bold mb-2">{{ $article->title }}</h2>

        <div class="d-flex flex-wrap gap-3 text-muted small mb-4">
            <span><i class="bi bi-person me-1"></i>{{ $article->user->name }}</span>
            <span><i class="bi bi-calendar3 me-1"></i>{{ $article->created_at->format('Y-m-d') }}</span>
            <span><i class="bi bi-eye me-1"></i>{{ number_format($article->view_count) }} views</span>
            <span><i class="bi bi-hand-thumbs-up me-1"></i>{{ $article->recommend_count }} recommends</span>
        </div>

        <div class="article-body lh-lg">{!! nl2br(e($article->body)) !!}</div>

        {{-- Recommend button --}}
        <div class="d-flex align-items-center gap-3 mt-4 pt-3 border-top">
            <form method="POST" action="{{ route('articles.recommend',$article) }}">
                @csrf
                <button class="btn {{ $recommended ? 'btn-primary' : 'btn-outline-primary' }}">
                    <i class="bi bi-hand-thumbs-up me-1"></i>
                    {{ $recommended ? 'Recommended' : 'Recommend' }}
                    <span class="badge {{ $recommended ? 'bg-white text-primary':'bg-primary' }} ms-1">
                        {{ $article->recommend_count }}
                    </span>
                </button>
            </form>
            <a href="{{ route('articles.index') }}" class="btn btn-outline-secondary ms-auto">
                <i class="bi bi-list-ul me-1"></i>List
            </a>
        </div>
    </div>
</div>

{{-- Instant Replies --}}
@if($instantReplies->isNotEmpty())
<div class="card border-0 shadow-sm mb-4" style="border-radius:12px!important;">
    <div class="card-header bg-white fw-semibold border-0 pt-3 pb-2">
        <i class="bi bi-lightning-fill text-warning me-1"></i>Quick Replies
    </div>
    <div class="card-body d-flex flex-wrap gap-2 pt-2">
        @foreach($instantReplies as $ir)
        <form method="POST" action="{{ route('articles.instant-replies.store',$article) }}">
            @csrf
            <input type="hidden" name="instant_reply_id" value="{{ $ir->id }}">
            <button type="submit" class="btn btn-outline-warning btn-sm">{{ $ir->title }}</button>
        </form>
        @endforeach
    </div>
</div>
@endif

{{-- Comments --}}
<div class="card border-0 shadow-sm mb-4" style="border-radius:12px!important;">
    <div class="card-header bg-white fw-semibold border-0 pt-3 pb-2">
        <i class="bi bi-chat-dots me-1"></i>Comments ({{ $article->approvedComments->count() }})
    </div>
    <div class="card-body">
        @forelse($article->approvedComments as $comment)
        <div class="d-flex gap-3 mb-3 pb-3 {{ !$loop->last ? 'border-bottom':'' }}">
            <div class="rounded-circle bg-secondary text-white d-flex align-items-center justify-content-center flex-shrink-0"
                 style="width:38px;height:38px;font-size:.8rem;">
                {{ strtoupper(substr($comment->user->name,0,1)) }}
            </div>
            <div class="flex-grow-1">
                <div class="d-flex justify-content-between">
                    <span class="fw-semibold small">{{ $comment->user->name }}</span>
                    <span class="text-muted small">{{ $comment->created_at->format('Y-m-d H:i') }}</span>
                </div>
                <p class="mb-0 mt-1 small">{{ $comment->body }}</p>
                @if($comment->isInstantReply())
                <span class="badge bg-warning text-dark mt-1" style="font-size:.6rem;">
                    <i class="bi bi-lightning-fill me-1"></i>Quick Reply
                </span>
                @endif
            </div>
        </div>
        @empty
        <p class="text-muted text-center mb-0 small">No comments yet. Be the first!</p>
        @endforelse
    </div>
</div>

{{-- Write comment --}}
<div class="card border-0 shadow-sm mb-4" style="border-radius:12px!important;">
    <div class="card-header bg-white fw-semibold border-0 pt-3 pb-2">Write a Comment</div>
    <div class="card-body">
        <form method="POST" action="{{ route('articles.comments.store',$article) }}">
            @csrf
            <div class="mb-3">
                <textarea name="body" class="form-control @error('body') is-invalid @enderror"
                          rows="4" placeholder="Share your thoughts…" required>{{ old('body') }}</textarea>
                @error('body')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <p class="text-muted small mb-3">
                <i class="bi bi-info-circle me-1"></i>Your comment will be visible after administrator approval.
            </p>
            <button type="submit" class="btn btn-primary">Post Comment</button>
        </form>
    </div>
</div>

{{-- Related articles --}}
@if($related->isNotEmpty())
<div class="mt-4">
    <h6 class="fw-bold mb-3">Related Articles</h6>
    <div class="row g-3">
        @foreach($related as $rel)
        <div class="col-md-4">
            <a href="{{ route('articles.show',$rel->slug) }}"
               class="card border-0 shadow-sm text-decoration-none h-100" style="border-radius:10px!important;">
                <div class="card-body p-3">
                    <span class="badge bg-secondary mb-1 small">{{ $rel->category->name }}</span>
                    <p class="fw-bold small text-dark mb-1 lh-sm">{{ Str::limit($rel->title, 60) }}</p>
                    <div class="text-muted" style="font-size:.72rem;">
                        <i class="bi bi-hand-thumbs-up me-1"></i>{{ $rel->recommend_count }}
                        <i class="bi bi-eye ms-2 me-1"></i>{{ number_format($rel->view_count) }}
                    </div>
                </div>
            </a>
        </div>
        @endforeach
    </div>
</div>
@endif

</div>
</div>
@endsection
