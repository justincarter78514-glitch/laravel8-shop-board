@extends('layouts.app')
@section('title', 'Bulletin Board')

@section('content')
<div class="row">
    <div class="col-md-3">
        <div class="card border-0 shadow-sm mb-3" style="border-radius:12px!important;">
            <div class="card-header bg-white fw-semibold border-0 pt-3 pb-2">Categories</div>
            <div class="list-group list-group-flush rounded-bottom">
                <a href="{{ route('articles.index') }}"
                   class="list-group-item list-group-item-action {{ !request('category_id') && !request('tag') ? 'active':'' }}">
                    All Posts
                </a>
                @foreach($categories as $cat)
                <a href="{{ route('articles.index',['category_id'=>$cat->id]) }}"
                   class="list-group-item list-group-item-action {{ request('category_id')==$cat->id ? 'active':'' }}">
                    {{ $cat->name }}
                </a>
                @endforeach
            </div>
        </div>

        {{-- Tags cloud --}}
        @if($popularTags->isNotEmpty())
        <div class="card border-0 shadow-sm mb-3" style="border-radius:12px!important;">
            <div class="card-header bg-white fw-semibold border-0 pt-3 pb-2">Popular Tags</div>
            <div class="card-body pt-2">
                @foreach($popularTags as $tag)
                <a href="{{ route('articles.index',['tag'=>$tag->slug]) }}"
                   class="badge text-decoration-none me-1 mb-1
                          {{ request('tag')===$tag->slug ? 'bg-primary' : 'bg-light text-dark border' }}"
                   style="font-size:.75rem;">
                    #{{ $tag->name }}
                    <span class="ms-1 opacity-75">{{ $tag->articles_count }}</span>
                </a>
                @endforeach
            </div>
        </div>
        @endif

        @auth
        <a href="{{ route('articles.create') }}" class="btn btn-primary w-100 mb-2">
            <i class="bi bi-pencil-square me-1"></i>Write Article
        </a>
        <a href="{{ route('articles.my') }}" class="btn btn-outline-secondary w-100">My Articles</a>
        @else
        <div class="card border-0 shadow-sm text-center p-4" style="border-radius:12px!important;">
            <i class="bi bi-lock-fill text-muted fs-2 mb-2"></i>
            <p class="small text-muted mb-3">Log in to read full articles and participate.</p>
            <a href="{{ route('login') }}" class="btn btn-primary btn-sm w-100 mb-2">Login</a>
            <a href="{{ route('register') }}" class="btn btn-outline-secondary btn-sm w-100">Register Free</a>
        </div>
        @endauth
    </div>

    <div class="col-md-9">
        <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
            <h5 class="mb-0 fw-bold">
                Bulletin Board
                @if(request('tag'))<span class="badge bg-primary ms-2">#{{ request('tag') }}</span>@endif
            </h5>
            <form method="GET" class="d-flex gap-2">
                @foreach(['category_id','tag'] as $param)
                    @if(request($param))<input type="hidden" name="{{ $param }}" value="{{ request($param) }}">@endif
                @endforeach
                <input type="text" name="search" class="form-control form-control-sm"
                       placeholder="Search…" value="{{ request('search') }}" style="width:200px;">
                <button class="btn btn-sm btn-outline-secondary"><i class="bi bi-search"></i></button>
            </form>
        </div>

        @guest
        <div class="alert border-0 mb-3 d-flex align-items-center gap-2"
             style="background:#eff6ff;color:#1e40af;border-radius:10px!important;">
            <i class="bi bi-info-circle-fill flex-shrink-0"></i>
            <span class="small">
                <a href="{{ route('login') }}" class="fw-bold text-decoration-none">Log in</a>
                to read full articles, post comments, and write your own posts.
            </span>
        </div>
        @endguest

        @forelse($articles as $article)
        <div class="card border-0 shadow-sm mb-3" style="border-radius:12px!important;">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start gap-2">
                    <div class="flex-grow-1">
                        <span class="badge bg-secondary me-1 mb-1">{{ $article->category->name }}</span>
                        {{-- Tags --}}
                        @foreach($article->tags->take(3) as $tag)
                        <a href="{{ route('articles.index',['tag'=>$tag->slug]) }}"
                           class="badge bg-light text-dark border text-decoration-none me-1 mb-1"
                           style="font-size:.65rem;">#{{ $tag->name }}</a>
                        @endforeach

                        <h6 class="fw-bold mb-1">
                            @auth
                            <a href="{{ route('articles.show',$article->slug) }}" class="text-decoration-none text-dark">
                                {{ $article->title }}
                            </a>
                            @else
                            <a href="{{ route('login') }}" class="text-decoration-none text-dark d-inline-flex align-items-center gap-1">
                                {{ $article->title }}
                                <i class="bi bi-lock-fill text-muted" style="font-size:.65rem;" title="Login to read"></i>
                            </a>
                            @endauth
                        </h6>

                        <p class="text-muted small mb-2 lh-base">
                            @auth
                                {{ Str::limit(strip_tags($article->body), 120) }}
                            @else
                                <span style="filter:blur(4px);user-select:none;pointer-events:none;">
                                    {{ Str::limit(strip_tags($article->body), 80) }}
                                </span>
                                <a href="{{ route('login') }}" class="ms-1 text-primary small fw-semibold text-decoration-none">Login to read →</a>
                            @endauth
                        </p>

                        <div class="d-flex gap-3 text-muted flex-wrap" style="font-size:.75rem;">
                            <span><i class="bi bi-person me-1"></i>{{ $article->user->name }}</span>
                            <span><i class="bi bi-calendar3 me-1"></i>{{ $article->created_at->format('Y-m-d') }}</span>
                            <span><i class="bi bi-chat me-1"></i>{{ $article->approved_comments_count }}</span>
                            <span><i class="bi bi-hand-thumbs-up me-1"></i>{{ $article->recommend_count }}</span>
                            <span><i class="bi bi-eye me-1"></i>{{ number_format($article->view_count) }}</span>
                        </div>
                    </div>
                    <small class="text-muted text-nowrap">{{ $article->created_at->diffForHumans() }}</small>
                </div>
            </div>
        </div>
        @empty
        <div class="text-center text-muted py-5">
            <i class="bi bi-inbox fs-1 d-block mb-2 opacity-25"></i>
            No articles found.
        </div>
        @endforelse

        {{ $articles->withQueryString()->links() }}
    </div>
</div>
@endsection
