@extends('layouts.app')
@section('title', 'Submit Article')

@section('content')
<div class="row justify-content-center">
<div class="col-lg-8">
<div class="card border-0 shadow-sm" style="border-radius:16px!important;">
    <div class="card-header bg-white fw-semibold border-0 pt-4 pb-2 px-4 d-flex justify-content-between align-items-center">
        <span>Submit an Article</span>
        <a href="{{ route('articles.index') }}" class="btn btn-sm btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i>Back
        </a>
    </div>
    <div class="card-body p-4">
        <div class="alert alert-info border-0 small mb-4" style="border-radius:10px!important;background:#eff6ff;color:#1e40af;">
            <i class="bi bi-info-circle me-1"></i>
            Your article will be reviewed by an administrator before it is published.
        </div>

        <form method="POST" action="{{ route('articles.store') }}">
            @csrf

            <div class="mb-3">
                <label class="form-label fw-semibold">Category <span class="text-danger">*</span></label>
                <select name="category_id" class="form-select @error('category_id') is-invalid @enderror" required>
                    <option value="">Select a category…</option>
                    @foreach($categories as $cat)
                    <option value="{{ $cat->id }}" {{ old('category_id')==$cat->id ? 'selected':'' }}>{{ $cat->name }}</option>
                    @endforeach
                </select>
                @error('category_id')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Title <span class="text-danger">*</span></label>
                <input type="text" name="title" class="form-control @error('title') is-invalid @enderror"
                       value="{{ old('title') }}" required>
                @error('title')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Content <span class="text-danger">*</span></label>
                <textarea name="body" class="form-control @error('body') is-invalid @enderror"
                          rows="12" required>{{ old('body') }}</textarea>
                @error('body')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>

            <div class="mb-4">
                <label class="form-label fw-semibold">Tags <span class="text-muted small">(optional)</span></label>
                <input type="text" name="tags" id="tagInput" class="form-control"
                       value="{{ old('tags') }}"
                       placeholder="Type a tag and press Enter or comma…">
                <div class="form-text">Separate tags with commas. e.g. recipe, organic, tips</div>
                <div id="tagPreview" class="d-flex flex-wrap gap-1 mt-2"></div>

                {{-- Suggestions --}}
                @if($allTags->isNotEmpty())
                <div class="mt-2">
                    <span class="text-muted small me-1">Suggestions:</span>
                    @foreach($allTags->take(15) as $tag)
                    <button type="button" class="btn btn-sm bg-light border text-muted mb-1"
                            style="font-size:.72rem;" onclick="addTag('{{ $tag->name }}')">
                        #{{ $tag->name }}
                    </button>
                    @endforeach
                </div>
                @endif
            </div>

            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">Submit for Review</button>
                <a href="{{ route('articles.index') }}" class="btn btn-outline-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
</div>
</div>
@endsection

@push('scripts')
<script>
const input = document.getElementById('tagInput');
const preview = document.getElementById('tagPreview');

function getTags() {
    return input.value.split(',').map(t=>t.trim()).filter(Boolean);
}

function renderTags() {
    preview.innerHTML = '';
    getTags().forEach(tag => {
        const span = document.createElement('span');
        span.className = 'badge bg-primary d-inline-flex align-items-center gap-1';
        span.style.fontSize = '.75rem';
        span.innerHTML = `#${tag} <button type="button" onclick="removeTag('${tag}')" style="background:none;border:none;color:#fff;padding:0;line-height:1;cursor:pointer;">✕</button>`;
        preview.appendChild(span);
    });
}

function addTag(name) {
    const tags = getTags();
    if (!tags.includes(name)) { tags.push(name); input.value = tags.join(', '); renderTags(); }
}

function removeTag(name) {
    input.value = getTags().filter(t=>t!==name).join(', ');
    renderTags();
}

input.addEventListener('keydown', e => {
    if (e.key===',' || e.key==='Enter') {
        e.preventDefault();
        const val = input.value.split(',').map(t=>t.trim()).filter(Boolean);
        input.value = val.join(', ');
        renderTags();
    }
});

input.addEventListener('blur', renderTags);

// Initial render if old value
if (input.value) renderTags();
</script>
@endpush
