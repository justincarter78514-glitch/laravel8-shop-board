@extends('layouts.app')
@section('title', 'My Wishlist')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="fw-bold mb-0"><i class="bi bi-heart-fill text-danger me-2"></i>My Wishlist</h4>
    <a href="{{ route('shop.index') }}" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-bag me-1"></i>Continue Shopping
    </a>
</div>

@if($items->isEmpty())
<div class="text-center py-5">
    <i class="bi bi-heart" style="font-size:3.5rem;color:#dee2e6;"></i>
    <p class="mt-3 text-muted">Your wishlist is empty.</p>
    <a href="{{ route('shop.index') }}" class="btn btn-primary">Browse Products</a>
</div>
@else
<div class="row g-4">
    @foreach($items as $item)
    @php $product = $item->product; @endphp
    <div class="col-sm-6 col-lg-4 col-xl-3">
        <div class="card border-0 shadow-sm h-100" style="border-radius:12px!important;">
            <div style="position:relative;">
                @if($product->main_image)
                <img src="{{ asset('storage/'.$product->main_image) }}" class="card-img-top"
                     style="height:180px;object-fit:cover;border-radius:12px 12px 0 0;">
                @else
                <div class="d-flex align-items-center justify-content-center bg-light"
                     style="height:180px;border-radius:12px 12px 0 0;font-size:3rem;">🛒</div>
                @endif

                {{-- Remove from wishlist --}}
                <form method="POST" action="{{ route('wishlist.toggle',$product) }}" style="position:absolute;top:10px;right:10px;">
                    @csrf
                    <button class="btn btn-sm btn-danger" style="border-radius:50%;width:32px;height:32px;padding:0;" title="Remove">
                        <i class="bi bi-heart-fill" style="font-size:.8rem;"></i>
                    </button>
                </form>
            </div>

            <div class="card-body d-flex flex-column p-3">
                <span class="badge bg-light text-dark border small mb-1 align-self-start">{{ $product->category->name }}</span>
                <h6 class="fw-bold mb-1 small">
                    <a href="{{ route('shop.show',$product->slug) }}" class="text-decoration-none text-dark">
                        {{ Str::limit($product->name, 50) }}
                    </a>
                </h6>

                <div class="mt-auto pt-2">
                    <div class="mb-2">
                        @if($product->isOnSale())
                            <span class="fw-bold text-danger">₩{{ number_format($product->sale_price) }}</span>
                            <span class="text-muted text-decoration-line-through small ms-1">₩{{ number_format($product->price) }}</span>
                        @else
                            <span class="fw-bold">₩{{ number_format($product->price) }}</span>
                        @endif
                    </div>

                    @if($product->inStock())
                    <form method="POST" action="{{ route('cart.add',$product) }}">
                        @csrf
                        <input type="hidden" name="quantity" value="1">
                        <button class="btn btn-primary btn-sm w-100" style="border-radius:8px;">
                            <i class="bi bi-cart-plus me-1"></i>Add to Cart
                        </button>
                    </form>
                    @else
                    <button class="btn btn-secondary btn-sm w-100" disabled style="border-radius:8px;">Out of Stock</button>
                    @endif
                </div>
            </div>
        </div>
    </div>
    @endforeach
</div>

<div class="mt-4">{{ $items->links() }}</div>
@endif
@endsection
