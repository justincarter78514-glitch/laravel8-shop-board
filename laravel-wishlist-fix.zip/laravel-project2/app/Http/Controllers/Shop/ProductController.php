<?php

namespace App\Http\Controllers\Shop;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductCategory;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    // Low stock threshold
    const LOW_STOCK = 5;

    public function index(Request $request)
    {
        $query = Product::active()->with('category');

        // Category filter
        if ($request->category) {
            $query->whereHas('category', fn($q) => $q->where('slug', $request->category));
        }

        // Keyword search
        if ($request->search) {
            $query->where(fn($q) =>
                $q->where('name','like',"%{$request->search}%")
                  ->orWhere('description','like',"%{$request->search}%")
            );
        }

        // Price range filter
        if ($request->filled('min_price')) {
            $query->where(fn($q) =>
                $q->whereRaw('COALESCE(sale_price, price) >= ?', [$request->min_price])
            );
        }
        if ($request->filled('max_price')) {
            $query->where(fn($q) =>
                $q->whereRaw('COALESCE(sale_price, price) <= ?', [$request->max_price])
            );
        }

        // In-stock filter
        if ($request->boolean('in_stock')) {
            $query->inStock();
        }

        // Min rating filter
        if ($request->filled('min_rating')) {
            $minRating = (int) $request->min_rating;
            $query->whereHas('approvedReviews', function ($q) use ($minRating) {
                $q->selectRaw('AVG(rating) as avg_r')
                  ->havingRaw('avg_r >= ?', [$minRating]);
            });
        }

        // Sort
        match($request->sort) {
            'price_asc'  => $query->orderByRaw('COALESCE(sale_price, price) ASC'),
            'price_desc' => $query->orderByRaw('COALESCE(sale_price, price) DESC'),
            'rating'     => $query->withAvg(['approvedReviews as avg_rating'], 'rating')
                                  ->orderByDesc('avg_rating'),
            'popular'    => $query->orderByDesc('recommend_count'),
            default      => $query->latest(),
        };

        $products   = $query->paginate(16)->withQueryString();
        $categories = ProductCategory::active()->topLevel()->ordered()->with('children')->get();

        // Price bounds for the slider
        $maxPrice = Product::active()->max(\DB::raw('COALESCE(sale_price, price)')) ?? 100000;

        return view('shop.products.index', compact('products','categories','maxPrice'));
    }

    public function show(Product $product)
    {
        abort_unless($product->is_active, 404);

        $related = Product::active()
            ->inStock()
            ->where('product_category_id', $product->product_category_id)
            ->where('id', '!=', $product->id)
            ->take(4)->get();

        // Wishlist state
        $inWishlist = auth()->check()
            ? \App\Models\Wishlist::where('user_id', auth()->id())
                ->where('product_id', $product->id)->exists()
            : false;

        return view('shop.products.show', compact('product','related','inWishlist'));
    }
}
