<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', config('app.name'))</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <style>
    /* ══════════════════════════════════════════════════════
       CSS VARIABLES & RESET
    ══════════════════════════════════════════════════════ */
    :root {
        --green:       #2E7D32;
        --green-light: #4CAF50;
        --green-pale:  #F1F8E9;
        --orange:      #F57C00;
        --accent:      #33A441;
        --dark:        #1C1C1C;
        --text:        #444;
        --border:      #E8F5E9;
        --font-head:   'Nunito', sans-serif;
        --font-body:   'Lato', sans-serif;
        --radius:      12px;
        --shadow:      0 4px 24px rgba(0,0,0,.08);
        --shadow-lg:   0 8px 40px rgba(0,0,0,.12);
    }

    *, *::before, *::after { box-sizing: border-box; }
    html { scroll-behavior: smooth; }
    body {
        font-family: var(--font-body);
        color: var(--text);
        overflow-x: hidden;
    }
    h1,h2,h3,h4,h5,h6 { font-family: var(--font-head); }

    /* ══════════════════════════════════════════════════════
       TOP BAR
    ══════════════════════════════════════════════════════ */
    .top-bar {
        background: var(--green);
        color: rgba(255,255,255,.85);
        font-size: .78rem;
        padding: 6px 0;
    }
    .top-bar a { color: inherit; text-decoration: none; }
    .top-bar a:hover { color: #fff; }

    /* ══════════════════════════════════════════════════════
       MAIN NAVBAR
    ══════════════════════════════════════════════════════ */
    .land-nav {
        background: #fff;
        box-shadow: 0 2px 12px rgba(0,0,0,.06);
        padding: 0;
        position: sticky;
        top: 0;
        z-index: 1030;
    }
    .land-nav .container {
        display: flex;
        align-items: stretch;
        gap: 0;
        min-height: 70px;
    }
    .nav-brand {
        display: flex;
        align-items: center;
        gap: 10px;
        text-decoration: none;
        padding: 0 24px 0 0;
        border-right: 1px solid var(--border);
        margin-right: 20px;
        flex-shrink: 0;
    }
    .nav-brand-logo { height: 44px; width: auto; object-fit: contain; }
    .nav-brand-text {
        font-family: var(--font-head);
        font-weight: 900;
        font-size: 1.3rem;
        color: var(--green);
        line-height: 1.1;
    }
    .nav-brand-text span { color: var(--orange); }

    .nav-links { display: flex; align-items: center; gap: 2px; flex: 1; }
    .nav-link-item {
        display: flex;
        align-items: center;
        padding: 0 14px;
        height: 70px;
        font-size: .88rem;
        font-weight: 600;
        font-family: var(--font-head);
        color: var(--dark);
        text-decoration: none;
        border-bottom: 3px solid transparent;
        transition: color .2s, border-color .2s;
        white-space: nowrap;
    }
    .nav-link-item:hover, .nav-link-item.active {
        color: var(--green);
        border-bottom-color: var(--green);
    }

    /* Nav Search */
    .nav-search { display: flex; align-items: center; padding: 0 16px; flex: 1; max-width: 340px; }
    .nav-search form { display: flex; width: 100%; }
    .nav-search input {
        border: 1px solid #ddd;
        border-right: none;
        border-radius: 8px 0 0 8px;
        padding: 8px 14px;
        font-size: .85rem;
        outline: none;
        flex: 1;
        min-width: 0;
        transition: border-color .2s;
    }
    .nav-search input:focus { border-color: var(--green-light); }
    .nav-search button {
        background: var(--green);
        color: #fff;
        border: none;
        border-radius: 0 8px 8px 0;
        padding: 8px 14px;
        cursor: pointer;
        transition: background .2s;
    }
    .nav-search button:hover { background: var(--accent); }

    /* Nav Icons */
    .nav-icons { display: flex; align-items: center; gap: 4px; padding: 0 0 0 12px; }
    .nav-icon-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 40px; height: 40px;
        border-radius: 8px;
        color: var(--dark);
        text-decoration: none;
        position: relative;
        font-size: 1.1rem;
        transition: background .2s, color .2s;
    }
    .nav-icon-btn:hover { background: var(--green-pale); color: var(--green); }
    .nav-badge {
        position: absolute; top: 3px; right: 3px;
        background: #E53935; color: #fff;
        font-size: .6rem; font-weight: 700;
        min-width: 16px; height: 16px;
        border-radius: 8px; display: flex;
        align-items: center; justify-content: center;
        padding: 0 3px;
    }

    /* Dropdown */
    .nav-user-wrap { position: relative; }
    .nav-user-btn {
        display: flex; align-items: center; gap: 8px;
        padding: 6px 12px; border-radius: 8px;
        cursor: pointer; border: 1px solid #eee;
        font-size: .85rem; font-weight: 600;
        font-family: var(--font-head);
        color: var(--dark); background: #fff;
        transition: all .2s;
        white-space: nowrap;
    }
    .nav-user-btn:hover { border-color: var(--green-light); color: var(--green); }
    .nav-user-avatar {
        width: 30px; height: 30px; border-radius: 50%;
        background: var(--green); color: #fff;
        display: flex; align-items: center; justify-content: center;
        font-size: .75rem; font-weight: 700; flex-shrink: 0;
        overflow: hidden;
    }
    .nav-user-avatar img { width: 100%; height: 100%; object-fit: cover; }

    .nav-dropdown {
        position: absolute; top: calc(100% + 8px); right: 0;
        background: #fff; border-radius: var(--radius);
        box-shadow: var(--shadow-lg);
        border: 1px solid #eee;
        min-width: 200px; z-index: 999;
        display: none;
        overflow: hidden;
    }
    .nav-user-wrap:hover .nav-dropdown,
    .nav-user-wrap.open .nav-dropdown { display: block; }
    .nav-dropdown a, .nav-dropdown button {
        display: flex; align-items: center; gap: 10px;
        padding: 10px 16px; font-size: .85rem;
        color: var(--text); text-decoration: none;
        border: none; background: none; width: 100%;
        transition: background .15s;
        font-family: var(--font-body);
    }
    .nav-dropdown a:hover, .nav-dropdown button:hover { background: var(--green-pale); color: var(--green); }
    .nav-dropdown hr { margin: 4px 0; border-color: #f0f0f0; }

    /* Mobile hamburger */
    .nav-toggler {
        display: none;
        background: none; border: 1px solid #ddd;
        border-radius: 8px; padding: 6px 10px;
        cursor: pointer; font-size: 1.2rem;
        color: var(--dark); margin-left: auto;
        align-items: center; justify-content: center;
    }
    @media (max-width: 991px) {
        .nav-links, .nav-search { display: none !important; }
        .nav-toggler { display: flex; }
        .land-nav .container { flex-wrap: wrap; padding: 12px 16px; min-height: unset; gap: 8px; }
        .nav-brand { border-right: none; margin-right: 0; padding-right: 0; }
        .nav-icons { padding-left: 0; }
        .mobile-menu {
            display: none; width: 100%;
            background: #fff; border-top: 1px solid var(--border);
            padding: 12px 0;
        }
        .mobile-menu.open { display: block; }
        .mobile-menu a {
            display: block; padding: 10px 16px;
            font-size: .9rem; font-weight: 600;
            color: var(--dark); text-decoration: none;
            font-family: var(--font-head);
        }
        .mobile-menu a:hover { color: var(--green); background: var(--green-pale); }
        .mobile-search { padding: 8px 16px; }
        .mobile-search form { display: flex; gap: 6px; }
        .mobile-search input { flex: 1; border: 1px solid #ddd; border-radius: 8px; padding: 8px 12px; outline: none; }
        .mobile-search button { background: var(--green); color: #fff; border: none; border-radius: 8px; padding: 8px 14px; cursor: pointer; }
    }

    /* ══════════════════════════════════════════════════════
       HERO
    ══════════════════════════════════════════════════════ */
    .hero-section { overflow: hidden; }
    .hero-slide {
        min-height: 580px; display: flex; align-items: center;
        position: relative; overflow: hidden;
    }
    .hero-slide .container { position: relative; z-index: 2; }
    .hero-text-col { padding: 60px 0; }
    .hero-badge {
        display: inline-flex; align-items: center;
        padding: 5px 16px; border-radius: 20px;
        font-size: .78rem; font-weight: 700;
        letter-spacing: 1px; text-transform: uppercase;
        margin-bottom: 16px; font-family: var(--font-head);
    }
    .hero-title {
        font-family: var(--font-head);
        font-size: clamp(2rem, 5vw, 3.4rem);
        font-weight: 900;
        color: #fff;
        line-height: 1.15;
        margin-bottom: 8px;
    }
    .hero-title span { color: #A5D6A7; }
    .hero-sub { font-size: .65em; font-weight: 700; opacity: .75; display: block; }
    .hero-desc { color: rgba(255,255,255,.75); font-size: 1rem; max-width: 460px; line-height: 1.7; margin-bottom: 8px; }

    .hero-circle-wrap {
        width: 400px; height: 400px; border-radius: 50%;
        border: 3px solid rgba(255,255,255,.15);
        display: flex; align-items: center; justify-content: center;
        overflow: hidden; position: relative;
        box-shadow: 0 20px 60px rgba(0,0,0,.3);
    }
    .hero-product-img { width: 100%; height: 100%; object-fit: cover; }

    .hero-deco-circle {
        position: absolute; border-radius: 50%; pointer-events: none;
    }
    .hero-deco-1 { width: 500px; height: 500px; right: -150px; bottom: -150px; }
    .hero-deco-2 { width: 300px; height: 300px; right: 80px; top: -80px; }

    .carousel-nav-btn {
        width: 44px; height: 44px; border-radius: 50%;
        background: rgba(255,255,255,.2);
        backdrop-filter: blur(8px);
        display: flex; align-items: center; justify-content: center;
        color: #fff; font-size: 1rem;
        transition: background .2s;
        border: 1px solid rgba(255,255,255,.3);
    }
    .carousel-nav-btn:hover { background: rgba(255,255,255,.35); }
    .carousel-control-prev, .carousel-control-next { width: 60px; }
    .carousel-indicators [data-bs-target] {
        width: 10px; height: 10px; border-radius: 50%;
        border: 2px solid rgba(255,255,255,.6);
        background: transparent;
    }
    .carousel-indicators .active { background: #fff; border-color: #fff; }

    /* ══════════════════════════════════════════════════════
       BUTTONS
    ══════════════════════════════════════════════════════ */
    .btn-accent {
        background: var(--accent); color: #fff;
        border: none; border-radius: 8px;
        font-family: var(--font-head); font-weight: 700;
        transition: background .2s, transform .15s, box-shadow .2s;
    }
    .btn-accent:hover {
        background: var(--green); color: #fff;
        transform: translateY(-1px);
        box-shadow: 0 4px 16px rgba(51,164,65,.35);
    }
    .btn-text-green {
        color: var(--green); font-weight: 700;
        font-family: var(--font-head); font-size: .88rem;
        text-decoration: none; transition: color .2s;
    }
    .btn-text-green:hover { color: var(--accent); }

    /* ══════════════════════════════════════════════════════
       FEATURES BAR
    ══════════════════════════════════════════════════════ */
    .features-bar { background: #fff; box-shadow: var(--shadow); }
    .feature-item {
        display: flex; align-items: center; gap: 16px;
        padding: 22px 28px;
    }
    .feature-border { border-right: 1px solid var(--border); }
    .feature-icon-wrap {
        width: 50px; height: 50px; border-radius: 12px;
        display: flex; align-items: center; justify-content: center;
        font-size: 1.3rem; flex-shrink: 0;
    }
    .feature-title { font-family: var(--font-head); font-weight: 800; font-size: .9rem; margin-bottom: 2px; }
    .feature-desc { font-size: .78rem; color: #888; }

    /* ══════════════════════════════════════════════════════
       SECTIONS COMMON
    ══════════════════════════════════════════════════════ */
    .section-pad { padding: 80px 0; }
    .section-tag {
        display: inline-block;
        color: var(--green-light); font-weight: 700;
        font-size: .75rem; letter-spacing: 2px;
        text-transform: uppercase; font-family: var(--font-head);
        margin-bottom: 8px;
    }
    .section-title {
        font-family: var(--font-head); font-weight: 900;
        font-size: clamp(1.6rem, 3vw, 2.2rem);
        color: var(--dark); line-height: 1.2;
    }
    .text-green { color: var(--green); }

    /* ══════════════════════════════════════════════════════
       CATEGORY CARDS
    ══════════════════════════════════════════════════════ */
    .cat-card {
        display: flex; flex-direction: column; align-items: center;
        padding: 20px 16px; border-radius: 16px;
        background: var(--cc-bg, #f5f5f5);
        min-width: 120px; transition: transform .25s, box-shadow .25s;
        cursor: pointer;
    }
    .cat-card:hover { transform: translateY(-5px); box-shadow: var(--shadow); }
    .cat-emoji { font-size: 2.4rem; margin-bottom: 10px; line-height: 1; }
    .cat-name {
        font-family: var(--font-head); font-weight: 700;
        font-size: .82rem; color: var(--cc-text, var(--dark));
        text-align: center; white-space: nowrap;
    }

    /* ══════════════════════════════════════════════════════
       PRODUCT CARDS
    ══════════════════════════════════════════════════════ */
    .prod-card {
        background: #fff; border-radius: var(--radius);
        box-shadow: var(--shadow); overflow: hidden;
        transition: transform .25s, box-shadow .25s;
        position: relative;
    }
    .prod-card:hover { transform: translateY(-6px); box-shadow: var(--shadow-lg); }
    .prod-badge {
        position: absolute; top: 12px; left: 12px;
        padding: 3px 10px; border-radius: 6px;
        font-size: .68rem; font-weight: 800;
        font-family: var(--font-head); z-index: 2;
        letter-spacing: .5px;
    }
    .prod-sale { background: #E53935; color: #fff; }
    .prod-new  { background: var(--green); color: #fff; }

    .prod-img-wrap { position: relative; overflow: hidden; height: 180px; background: var(--green-pale); }
    .prod-img { width: 100%; height: 100%; object-fit: cover; transition: transform .4s; }
    .prod-card:hover .prod-img { transform: scale(1.06); }
    .prod-img-ph {
        width: 100%; height: 100%;
        display: flex; align-items: center; justify-content: center;
        font-size: 3.5rem;
    }
    .prod-hover {
        position: absolute; bottom: 0; left: 0; right: 0;
        display: flex; justify-content: center; gap: 8px;
        padding: 12px; background: linear-gradient(to top, rgba(0,0,0,.5), transparent);
        transform: translateY(100%); transition: transform .3s;
    }
    .prod-card:hover .prod-hover { transform: translateY(0); }
    .prod-action {
        width: 36px; height: 36px; border-radius: 50%;
        background: #fff; color: var(--green);
        display: flex; align-items: center; justify-content: center;
        font-size: .95rem; text-decoration: none;
        border: none; cursor: pointer; transition: background .2s, color .2s;
        box-shadow: 0 2px 8px rgba(0,0,0,.15);
    }
    .prod-action:hover { background: var(--green); color: #fff; }

    .prod-body { padding: 14px 16px; }
    .prod-cat-label { font-size: .7rem; color: #999; font-weight: 600; text-transform: uppercase; letter-spacing: .5px; }
    .prod-name { font-family: var(--font-head); font-weight: 700; font-size: .92rem; margin: 4px 0 8px; line-height: 1.3; }
    .prod-name a { color: var(--dark); text-decoration: none; }
    .prod-name a:hover { color: var(--green); }
    .prod-price { display: flex; align-items: center; gap: 8px; }
    .price-now { font-family: var(--font-head); font-weight: 900; color: var(--green); font-size: 1.05rem; }
    .price-was { font-size: .8rem; color: #bbb; text-decoration: line-through; }

    /* ══════════════════════════════════════════════════════
       OFFER BANNERS
    ══════════════════════════════════════════════════════ */
    .offer-card {
        border-radius: 16px; overflow: hidden;
        display: flex; align-items: center;
        justify-content: space-between;
        padding: 30px 28px; min-height: 200px;
        gap: 16px;
    }
    .offer-eyebrow { font-size: .72rem; font-weight: 700; letter-spacing: 2px; text-transform: uppercase; color: rgba(255,255,255,.7); display: block; margin-bottom: 6px; }
    .offer-headline { font-family: var(--font-head); font-weight: 900; font-size: 1.45rem; line-height: 1.3; margin-bottom: 0; }
    .offer-img { height: 160px; width: 160px; object-fit: cover; border-radius: 12px; flex-shrink: 0; }

    /* ══════════════════════════════════════════════════════
       COUNTDOWN
    ══════════════════════════════════════════════════════ */
    .countdown-row { display: flex; align-items: center; justify-content: center; gap: 8px; }
    .cd-label { font-size: .85rem; color: #888; font-weight: 600; }
    .cd-box {
        background: var(--green); color: #fff;
        font-family: var(--font-head); font-weight: 900;
        font-size: 1.4rem; width: 52px; height: 52px;
        border-radius: 10px; display: flex;
        align-items: center; justify-content: center;
        box-shadow: 0 4px 12px rgba(46,125,50,.3);
    }
    .cd-sep { font-weight: 900; color: var(--green); font-size: 1.3rem; }

    /* ══════════════════════════════════════════════════════
       DEAL CARDS
    ══════════════════════════════════════════════════════ */
    .deal-card { background: #fff; border-radius: var(--radius); box-shadow: var(--shadow); overflow: hidden; }
    .deal-img-wrap { position: relative; height: 180px; overflow: hidden; background: var(--green-pale); }
    .deal-img { width: 100%; height: 100%; object-fit: cover; }
    .deal-disc-badge {
        position: absolute; top: 10px; right: 10px;
        background: #E53935; color: #fff;
        font-family: var(--font-head); font-weight: 800; font-size: .75rem;
        padding: 4px 10px; border-radius: 20px;
    }
    .deal-body { padding: 14px 16px; }
    .stock-bar { height: 5px; background: #eee; border-radius: 3px; margin-bottom: 4px; }
    .stock-fill { height: 100%; background: linear-gradient(to right, var(--green-light), var(--orange)); border-radius: 3px; }
    .stock-label { font-size: .72rem; color: #E53935; font-weight: 600; }

    /* ══════════════════════════════════════════════════════
       WHY CHOOSE US
    ══════════════════════════════════════════════════════ */
    .why-wrap { position: relative; display: inline-block; }
    .why-img { width: 100%; border-radius: 20px; box-shadow: var(--shadow-lg); }
    .why-float-badge {
        position: absolute; bottom: 24px; right: -20px;
        background: var(--green); color: #fff;
        border-radius: 16px; padding: 16px 24px;
        text-align: center; box-shadow: var(--shadow-lg);
        border: 4px solid #fff;
    }
    .why-float-num { font-family: var(--font-head); font-weight: 900; font-size: 2rem; line-height: 1; }
    .why-float-sub { font-size: .75rem; opacity: .85; }
    .why-item { display: flex; gap: 14px; align-items: flex-start; }
    .why-icon-box {
        width: 44px; height: 44px; border-radius: 12px;
        display: flex; align-items: center; justify-content: center;
        font-size: 1.2rem; flex-shrink: 0;
    }

    /* ══════════════════════════════════════════════════════
       BLOG CARDS
    ══════════════════════════════════════════════════════ */
    .blog-card { background: #fff; border-radius: var(--radius); box-shadow: var(--shadow); overflow: hidden; height: 100%; transition: transform .25s; }
    .blog-card:hover { transform: translateY(-4px); }
    .blog-img-wrap { position: relative; height: 200px; overflow: hidden; }
    .blog-img { width: 100%; height: 100%; object-fit: cover; transition: transform .4s; }
    .blog-card:hover .blog-img { transform: scale(1.05); }
    .blog-tag {
        position: absolute; top: 14px; left: 14px;
        background: var(--green); color: #fff;
        font-size: .7rem; font-weight: 700; padding: 4px 12px;
        border-radius: 20px; font-family: var(--font-head);
    }
    .blog-body { padding: 18px 20px; }
    .blog-meta { font-size: .75rem; color: #aaa; margin-bottom: 8px; }
    .blog-title { font-family: var(--font-head); font-weight: 800; font-size: .95rem; line-height: 1.4; margin-bottom: 8px; }
    .blog-title a { color: var(--dark); text-decoration: none; }
    .blog-title a:hover { color: var(--green); }
    .blog-excerpt { font-size: .82rem; color: #888; line-height: 1.6; margin-bottom: 12px; }
    .blog-more { font-size: .82rem; font-weight: 700; color: var(--green); text-decoration: none; font-family: var(--font-head); }
    .blog-more:hover { color: var(--accent); }

    /* ══════════════════════════════════════════════════════
       TESTIMONIALS
    ══════════════════════════════════════════════════════ */
    .testi-card {
        background: #fff; border-radius: var(--radius);
        padding: 28px; box-shadow: var(--shadow);
        border-top: 4px solid var(--green); height: 100%;
        position: relative;
    }
    .testi-quote {
        position: absolute; top: 16px; right: 20px;
        font-size: 4rem; color: var(--green-pale);
        font-family: Georgia, serif; line-height: 1;
        pointer-events: none;
    }
    .testi-text { font-size: .9rem; line-height: 1.7; color: #555; margin-bottom: 14px; }
    .testi-stars { color: #FFB300; font-size: 1rem; margin-bottom: 16px; letter-spacing: 2px; }
    .testi-author { display: flex; align-items: center; gap: 12px; }
    .testi-avatar {
        width: 44px; height: 44px; border-radius: 50%;
        background: var(--green); color: #fff;
        display: flex; align-items: center; justify-content: center;
        font-family: var(--font-head); font-weight: 800;
        font-size: 1rem; flex-shrink: 0;
    }
    .testi-name { font-family: var(--font-head); font-weight: 800; font-size: .88rem; }
    .testi-role { font-size: .75rem; color: #aaa; }

    /* ══════════════════════════════════════════════════════
       NEWSLETTER
    ══════════════════════════════════════════════════════ */
    .nl-section { background: linear-gradient(135deg, var(--green) 0%, #1B5E20 100%); padding: 70px 0; }
    .nl-inner { position: relative; }
    .nl-eyebrow { font-size: .72rem; font-weight: 700; letter-spacing: 2px; text-transform: uppercase; color: #A5D6A7; display: block; margin-bottom: 8px; }
    .nl-title { font-family: var(--font-head); font-weight: 900; font-size: clamp(1.4rem, 3vw, 2rem); color: #fff; line-height: 1.2; margin-bottom: 6px; }
    .nl-title span { color: #A5D6A7; }
    .nl-form .nl-row { display: flex; gap: 8px; }
    .nl-input {
        flex: 1; min-width: 0;
        border: 2px solid rgba(255,255,255,.3);
        background: rgba(255,255,255,.1);
        border-radius: 10px; padding: 12px 18px;
        font-size: .9rem; color: #fff; outline: none;
        transition: border-color .2s;
    }
    .nl-input::placeholder { color: rgba(255,255,255,.55); }
    .nl-input:focus { border-color: rgba(255,255,255,.7); background: rgba(255,255,255,.15); }
    .nl-btn {
        background: #fff; color: var(--green);
        border: none; border-radius: 10px;
        padding: 12px 24px; font-weight: 800;
        font-family: var(--font-head); font-size: .9rem;
        cursor: pointer; white-space: nowrap;
        transition: background .2s, transform .15s;
    }
    .nl-btn:hover { background: #E8F5E9; transform: translateY(-1px); }
    .nl-success-msg { display: none; color: #A5D6A7; font-weight: 700; margin-top: 12px; font-family: var(--font-head); }
    .nl-success-state .nl-row { display: none; }
    .nl-success-state .nl-success-msg { display: block; }

    /* ══════════════════════════════════════════════════════
       FOOTER
    ══════════════════════════════════════════════════════ */
    .site-footer { background: #1C2A1C; color: rgba(255,255,255,.75); padding: 60px 0 0; }
    .footer-logo { font-family: var(--font-head); font-weight: 900; font-size: 1.4rem; color: #fff; margin-bottom: 12px; display: block; }
    .footer-logo span { color: #A5D6A7; }
    .footer-about { font-size: .83rem; line-height: 1.7; color: rgba(255,255,255,.55); margin-bottom: 16px; }
    .footer-social { display: flex; gap: 8px; }
    .footer-soc-btn {
        width: 36px; height: 36px; border-radius: 8px;
        background: rgba(255,255,255,.08); color: rgba(255,255,255,.7);
        display: flex; align-items: center; justify-content: center;
        text-decoration: none; transition: background .2s, color .2s;
    }
    .footer-soc-btn:hover { background: var(--green); color: #fff; }
    .footer-heading { font-family: var(--font-head); font-weight: 800; font-size: .85rem; color: #fff; margin-bottom: 18px; letter-spacing: .5px; text-transform: uppercase; }
    .footer-links { list-style: none; padding: 0; margin: 0; }
    .footer-links li { margin-bottom: 10px; }
    .footer-links a { color: rgba(255,255,255,.5); text-decoration: none; font-size: .83rem; transition: color .2s; }
    .footer-links a:hover { color: #A5D6A7; }
    .footer-contact-item { display: flex; gap: 10px; align-items: flex-start; margin-bottom: 12px; font-size: .83rem; color: rgba(255,255,255,.5); }
    .footer-contact-item i { color: var(--green-light); margin-top: 2px; flex-shrink: 0; }
    .footer-bottom { border-top: 1px solid rgba(255,255,255,.08); padding: 18px 0; margin-top: 40px; }
    .footer-bottom-text { font-size: .78rem; color: rgba(255,255,255,.35); }

    /* ══════════════════════════════════════════════════════
       GO TO TOP
    ══════════════════════════════════════════════════════ */
    #goToTop {
        position: fixed; bottom: 28px; right: 28px;
        width: 44px; height: 44px; border-radius: 12px;
        background: var(--green); color: #fff; border: none;
        box-shadow: 0 4px 16px rgba(46,125,50,.4);
        display: flex; align-items: center; justify-content: center;
        font-size: 1rem; cursor: pointer;
        opacity: 0; transform: translateY(12px);
        transition: opacity .3s, transform .3s, background .2s;
        z-index: 1050;
    }
    #goToTop.visible { opacity: 1; transform: translateY(0); }
    #goToTop:hover { background: var(--accent); }

    /* ══════════════════════════════════════════════════════
       FLASH ALERTS
    ══════════════════════════════════════════════════════ */
    .flash-wrap { position: fixed; top: 80px; right: 20px; z-index: 2000; min-width: 280px; max-width: 360px; }
    .flash-toast {
        background: #fff; border-radius: 12px;
        box-shadow: var(--shadow-lg); padding: 14px 18px;
        margin-bottom: 10px; display: flex; align-items: center;
        gap: 12px; animation: slideInRight .35s ease;
        border-left: 4px solid var(--green);
    }
    .flash-toast.flash-error { border-left-color: #E53935; }
    .flash-toast i { font-size: 1.2rem; }
    @keyframes slideInRight { from { transform: translateX(40px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }

    /* ══════════════════════════════════════════════════════
       SEARCH HIGHLIGHT
    ══════════════════════════════════════════════════════ */
    .search-highlight { background: #fff176; padding: 0 2px; border-radius: 2px; }
    </style>

    @stack('styles')
</head>
<body>

{{-- ── TOP BAR ──────────────────────────────────────────────────────────── --}}
<div class="top-bar">
    <div class="container d-flex justify-content-between align-items-center flex-wrap gap-1">
        <div class="d-flex align-items-center gap-3">
            @php $phone = \App\Models\SiteSetting::get('contact_phone'); $email = \App\Models\SiteSetting::get('contact_email'); @endphp
            @if($phone)<span><i class="bi bi-telephone me-1"></i><a href="tel:{{ $phone }}">{{ $phone }}</a></span>@endif
            @if($email)<span><i class="bi bi-envelope me-1"></i><a href="mailto:{{ $email }}">{{ $email }}</a></span>@endif
        </div>
        <div class="d-flex align-items-center gap-3">
            @php $hours = \App\Models\SiteSetting::get('contact_hours'); @endphp
            @if($hours)<span><i class="bi bi-clock me-1"></i>{{ $hours }}</span>@endif
            <span>Free delivery on orders over ₩50,000</span>
        </div>
    </div>
</div>

{{-- ── MAIN NAVBAR ──────────────────────────────────────────────────────── --}}
<nav class="land-nav">
    <div class="container">
        {{-- Brand --}}
        <a href="{{ route('home') }}" class="nav-brand">
            @php $logo = \App\Models\SiteSetting::get('site_logo'); @endphp
            @if($logo)
                <img src="{{ asset('storage/'.$logo) }}" alt="{{ config('app.name') }}" class="nav-brand-logo">
            @else
                <div style="width:44px;height:44px;background:var(--green);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.5rem;">🛒</div>
            @endif
            <div class="nav-brand-text">{{ config('app.name') }}<br><span style="font-size:.65em;color:var(--orange);font-weight:700;">Fresh & Organic</span></div>
        </a>

        {{-- Nav links --}}
        <div class="nav-links">
            <a href="{{ route('home') }}" class="nav-link-item {{ request()->routeIs('home') ? 'active' : '' }}">Home</a>
            <a href="{{ route('shop.index') }}" class="nav-link-item {{ request()->routeIs('shop.*') ? 'active' : '' }}">Shop</a>
            <a href="{{ route('articles.index') }}" class="nav-link-item {{ request()->routeIs('articles.*') ? 'active' : '' }}">Board</a>
            <a href="{{ route('about') }}" class="nav-link-item {{ request()->routeIs('about') ? 'active' : '' }}">About</a>
            <a href="{{ route('faq') }}" class="nav-link-item {{ request()->routeIs('faq') ? 'active' : '' }}">FAQ</a>
        </div>

        {{-- Search --}}
        <div class="nav-search">
            <form method="GET" action="{{ route('search') }}">
                <input type="text" name="q" placeholder="Search products, articles…"
                       value="{{ request('q') }}" autocomplete="off">
                <button type="submit"><i class="bi bi-search"></i></button>
            </form>
        </div>

        {{-- Icons --}}
        <div class="nav-icons">
            <a href="{{ route('cart.index') }}" class="nav-icon-btn">
                <i class="bi bi-cart3"></i>
                @php $cartCount = auth()->check() ? \App\Models\CartItem::where('user_id',auth()->id())->sum('quantity') : \App\Models\CartItem::where('session_id',session()->getId())->sum('quantity'); @endphp
                @if($cartCount > 0)<span class="nav-badge">{{ $cartCount }}</span>@endif
            </a>

            @auth
            @php
                $uid = auth()->id();
                $unread = \App\Models\Notification::active()->forUser($uid)
                    ->whereDoesntHave('reads', fn($q)=>$q->where('user_id',$uid))->count();
                $wishlistCount = \App\Models\Wishlist::where('user_id',$uid)->count();
            @endphp
            <a href="{{ route('wishlist.index') }}" class="nav-icon-btn" title="Wishlist">
                <i class="bi bi-heart"></i>
                @if($wishlistCount > 0)<span class="nav-badge" style="background:#e91e63;">{{ $wishlistCount > 9 ? '9+' : $wishlistCount }}</span>@endif
            </a>
            <a href="{{ route('notifications.index') }}" class="nav-icon-btn">
                <i class="bi bi-bell{{ $unread>0?'-fill':'' }}" style="{{ $unread>0?'color:var(--orange)':'' }}"></i>
                @if($unread>0)<span class="nav-badge">{{ $unread>9?'9+':$unread }}</span>@endif
            </a>

            <div class="nav-user-wrap">
                <div class="nav-user-btn">
                    <div class="nav-user-avatar">
                        @if(auth()->user()->avatar)
                            <img src="{{ asset('storage/'.auth()->user()->avatar) }}" alt="">
                        @else
                            {{ strtoupper(substr(auth()->user()->name,0,1)) }}
                        @endif
                    </div>
                    <span class="d-none d-xl-inline">{{ Str::limit(auth()->user()->name, 12) }}</span>
                    <i class="bi bi-chevron-down" style="font-size:.7rem;"></i>
                </div>
                <div class="nav-dropdown">
                    <a href="{{ route('profile.show') }}"><i class="bi bi-person"></i>My Profile</a>
                    <a href="{{ route('wishlist.index') }}"><i class="bi bi-heart"></i>My Wishlist</a>
                    <a href="{{ route('orders.index') }}"><i class="bi bi-receipt"></i>My Orders</a>
                    <a href="{{ route('articles.my') }}"><i class="bi bi-file-earmark-text"></i>My Articles</a>
                    @if(auth()->user()->hasAnyAdminAccess())
                    <hr>
                    <a href="{{ route('admin.dashboard') }}" style="color:#E53935;"><i class="bi bi-shield-lock"></i>Admin Panel</a>
                    @endif
                    <hr>
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <button type="submit"><i class="bi bi-box-arrow-right"></i>Logout</button>
                    </form>
                </div>
            </div>
            @else
            <a href="{{ route('login') }}" class="nav-icon-btn" title="Login"><i class="bi bi-person"></i></a>
            <a href="{{ route('register') }}" class="btn btn-accent btn-sm px-3 ms-1" style="font-size:.82rem;">Register</a>
            @endauth
        </div>

        {{-- Mobile toggle --}}
        <button class="nav-toggler" onclick="document.getElementById('mobileMenu').classList.toggle('open')">
            <i class="bi bi-list"></i>
        </button>
    </div>

    {{-- Mobile menu --}}
    <div id="mobileMenu" class="mobile-menu">
        <div class="mobile-search">
            <form method="GET" action="{{ route('search') }}">
                <input type="text" name="q" placeholder="Search…" value="{{ request('q') }}">
                <button type="submit"><i class="bi bi-search"></i></button>
            </form>
        </div>
        <a href="{{ route('home') }}">Home</a>
        <a href="{{ route('shop.index') }}">Shop</a>
        <a href="{{ route('articles.index') }}">Board</a>
        <a href="{{ route('about') }}">About</a>
        <a href="{{ route('faq') }}">FAQ</a>
        @auth
        <a href="{{ route('profile.show') }}">My Profile</a>
        <a href="{{ route('orders.index') }}">My Orders</a>
        <a href="{{ route('cart.index') }}">Cart @if($cartCount > 0)({{ $cartCount }})@endif</a>
        @auth
        <a href="{{ route('wishlist.index') }}">Wishlist @php $wc=\App\Models\Wishlist::where('user_id',auth()->id())->count(); @endphp @if($wc > 0)({{ $wc }})@endif</a>
        @endauth
        @else
        <a href="{{ route('login') }}">Login</a>
        <a href="{{ route('register') }}">Register</a>
        @endauth
    </div>
</nav>

{{-- ── FLASH TOASTS ─────────────────────────────────────────────────────── --}}
<div class="flash-wrap" id="flashWrap">
    @foreach(['success','error','warning','info'] as $type)
    @if(session($type))
    <div class="flash-toast {{ $type==='error'?'flash-error':'' }}" id="flash-{{ $type }}">
        <i class="bi bi-{{ $type==='success'?'check-circle-fill text-success':($type==='error'?'x-circle-fill text-danger':'info-circle-fill text-info') }}"></i>
        <span>{{ session($type) }}</span>
    </div>
    @endif
    @endforeach
    @if($errors->any())
    <div class="flash-toast flash-error">
        <i class="bi bi-x-circle-fill text-danger"></i>
        <span>{{ $errors->first() }}</span>
    </div>
    @endif
</div>

{{-- ── MAIN CONTENT ─────────────────────────────────────────────────────── --}}
@yield('content')

{{-- ── FOOTER ──────────────────────────────────────────────────────────── --}}
<footer class="site-footer">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-4 col-md-6">
                <a href="{{ route('home') }}" class="footer-logo">
                    {{ config('app.name') }} <span>.</span>
                </a>
                <p class="footer-about">
                    {{ \App\Models\SiteSetting::get('about_subtitle', 'Your trusted source for fresh organic produce and natural groceries delivered daily.') }}
                </p>
                <div class="footer-social">
                    @php $ig=\App\Models\SiteSetting::get('social_instagram'); $fb=\App\Models\SiteSetting::get('social_facebook'); $yt=\App\Models\SiteSetting::get('social_youtube'); $tw=\App\Models\SiteSetting::get('social_twitter'); @endphp
                    @if($ig)<a href="{{ $ig }}" target="_blank" class="footer-soc-btn"><i class="bi bi-instagram"></i></a>@endif
                    @if($fb)<a href="{{ $fb }}" target="_blank" class="footer-soc-btn"><i class="bi bi-facebook"></i></a>@endif
                    @if($yt)<a href="{{ $yt }}" target="_blank" class="footer-soc-btn"><i class="bi bi-youtube"></i></a>@endif
                    @if($tw)<a href="{{ $tw }}" target="_blank" class="footer-soc-btn"><i class="bi bi-twitter-x"></i></a>@endif
                </div>
            </div>

            <div class="col-lg-2 col-md-6 col-6">
                <h6 class="footer-heading">Shop</h6>
                <ul class="footer-links">
                    <li><a href="{{ route('shop.index') }}">All Products</a></li>
                    <li><a href="{{ route('shop.index') }}">Fresh Vegetables</a></li>
                    <li><a href="{{ route('shop.index') }}">Fresh Fruits</a></li>
                    <li><a href="{{ route('cart.index') }}">My Cart</a></li>
                    @auth<li><a href="{{ route('orders.index') }}">My Orders</a></li>@endauth
                </ul>
            </div>

            <div class="col-lg-2 col-md-6 col-6">
                <h6 class="footer-heading">Company</h6>
                <ul class="footer-links">
                    <li><a href="{{ route('about') }}">About Us</a></li>
                    <li><a href="{{ route('faq') }}">FAQ</a></li>
                    <li><a href="{{ route('articles.index') }}">Community Board</a></li>
                    @guest<li><a href="{{ route('register') }}">Create Account</a></li>@endguest
                </ul>
            </div>

            <div class="col-lg-4 col-md-6">
                <h6 class="footer-heading">Contact Us</h6>
                @php $addr=\App\Models\SiteSetting::get('contact_address'); @endphp
                @if($addr)<div class="footer-contact-item"><i class="bi bi-geo-alt-fill"></i><span>{{ $addr }}</span></div>@endif
                @if($phone)<div class="footer-contact-item"><i class="bi bi-telephone-fill"></i><a href="tel:{{ $phone }}" style="color:inherit;text-decoration:none;">{{ $phone }}</a></div>@endif
                @if($email)<div class="footer-contact-item"><i class="bi bi-envelope-fill"></i><a href="mailto:{{ $email }}" style="color:inherit;text-decoration:none;">{{ $email }}</a></div>@endif
                @if($hours)<div class="footer-contact-item"><i class="bi bi-clock-fill"></i><span>{{ $hours }}</span></div>@endif
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container d-flex justify-content-between align-items-center flex-wrap gap-2">
            <span class="footer-bottom-text">&copy; {{ date('Y') }} {{ config('app.name') }}. All rights reserved.</span>
            <div class="d-flex gap-2">
                <img src="https://cdn.jsdelivr.net/gh/twitter/twemoji@14/assets/svg/1f4b3.svg" style="height:20px;" alt="visa">
                <img src="https://cdn.jsdelivr.net/gh/twitter/twemoji@14/assets/svg/1f4b0.svg" style="height:20px;" alt="payment">
            </div>
        </div>
    </div>
</footer>

{{-- Go-to-top --}}
<button id="goToTop" title="Back to top"><i class="bi bi-chevron-up"></i></button>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Go-to-top
const gtt = document.getElementById('goToTop');
window.addEventListener('scroll', () => gtt.classList.toggle('visible', scrollY > 400), { passive:true });
gtt.addEventListener('click', () => scrollTo({ top:0, behavior:'smooth' }));

// Auto-dismiss flash toasts
document.querySelectorAll('.flash-toast').forEach(t => setTimeout(() => t.style.opacity = '0', 4000));
</script>
@stack('scripts')
</body>
</html>
