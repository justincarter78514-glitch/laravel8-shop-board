@extends('layouts.app')
@section('title', $product->name)

@section('content')

{{-- Breadcrumb --}}
<nav aria-label="breadcrumb" class="mb-4">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="{{ route('shop.index') }}">Shop</a></li>
        <li class="breadcrumb-item">
            <a href="{{ route('shop.index', ['category'=>$product->category->slug]) }}">{{ $product->category->name }}</a>
        </li>
        <li class="breadcrumb-item active">{{ $product->name }}</li>
    </ol>
</nav>

@php
    $allImages   = $product->allImages();
    $imageUrls   = $product->allImageUrls();
    $avgRating   = $product->averageRating();
    $reviewCount = $product->reviewCount();
    $distribution = $product->ratingDistribution();
    $approvedReviews = $product->approvedReviews()->with('user')->get();
    $userHasReviewed = auth()->check() ? $product->hasReviewFrom(auth()->id()) : false;
@endphp

{{-- ── Product Section ─────────────────────────────────────────────────── --}}
<div class="row g-5 mb-5">

    {{-- Gallery column --}}
    <div class="col-lg-5">
        {{-- Main display image --}}
        <div class="product-main-img-wrap mb-3" onclick="openLightbox(0)">
            @if(count($imageUrls) > 0)
                <img id="mainDisplay" src="{{ $imageUrls[0] }}"
                     alt="{{ $product->name }}" class="product-main-img">
                <div class="zoom-hint"><i class="bi bi-zoom-in me-1"></i>Click to enlarge</div>
            @else
                <div class="product-main-img-placeholder">
                    <i class="bi bi-image text-muted" style="font-size:4rem;"></i>
                </div>
            @endif
        </div>

        {{-- Thumbnail strip --}}
        @if(count($imageUrls) > 1)
        <div class="thumb-strip">
            @foreach($imageUrls as $i => $url)
            <div class="thumb-item {{ $i === 0 ? 'active' : '' }}"
                 onclick="switchMain({{ $i }}, this)">
                <img src="{{ $url }}" alt="Image {{ $i+1 }}">
            </div>
            @endforeach
        </div>
        @endif
    </div>

    {{-- Product info column --}}
    <div class="col-lg-7">
        <span class="badge bg-light text-dark border mb-2">{{ $product->category->name }}</span>

        @if($product->isOnSale())
            <span class="badge bg-danger ms-1 mb-2">SALE</span>
        @endif

        <h1 class="fw-bold mb-2" style="font-size:1.8rem;">{{ $product->name }}</h1>

        {{-- Star rating summary --}}
        @if($reviewCount > 0)
        <div class="d-flex align-items-center gap-2 mb-3">
            <div class="stars-display">
                @for($i = 1; $i <= 5; $i++)
                    <i class="bi bi-star{{ $i <= round($avgRating) ? '-fill text-warning' : ' text-muted' }}"
                       style="font-size:.9rem;"></i>
                @endfor
            </div>
            <span class="fw-bold">{{ $avgRating }}</span>
            <a href="#reviews" class="text-muted small text-decoration-none">
                ({{ $reviewCount }} review{{ $reviewCount !== 1 ? 's' : '' }})
            </a>
        </div>
        @else
        <div class="text-muted small mb-3">No reviews yet — be the first!</div>
        @endif

        {{-- Price --}}
        <div class="mb-3">
            @if($product->isOnSale())
                <span class="fs-2 fw-bold text-danger">₩{{ number_format($product->sale_price) }}</span>
                <span class="fs-5 text-muted text-decoration-line-through ms-2">₩{{ number_format($product->price) }}</span>
                @php $discPct = round((1 - $product->sale_price/$product->price)*100); @endphp
                <span class="badge bg-danger ms-2">{{ $discPct }}% OFF</span>
            @else
                <span class="fs-2 fw-bold">₩{{ number_format($product->price) }}</span>
            @endif
        </div>

        {{-- Description --}}
        @if($product->description)
        <p class="text-muted lh-lg mb-4">{{ $product->description }}</p>
        @endif

        {{-- Stock --}}
        <div class="mb-4">
            @if($product->inStock())
                <span class="text-success fw-semibold">
                    <i class="bi bi-check-circle-fill me-1"></i>In Stock
                    @if($product->track_stock)
                        <span class="text-muted fw-normal">({{ $product->stock }} available)</span>
                    @endif
                </span>
            @else
                <span class="text-danger fw-semibold"><i class="bi bi-x-circle-fill me-1"></i>Out of Stock</span>
            @endif
        </div>

        {{-- Add to cart + Wishlist --}}
        @if($product->inStock())
        <form method="POST" action="{{ route('cart.add', $product) }}" class="d-flex gap-3 align-items-center mb-3 flex-wrap">
            @csrf
            <div class="qty-wrap">
                <button type="button" class="qty-btn" onclick="adjustQty(-1)">−</button>
                <input type="number" name="quantity" id="qtyInput"
                       class="qty-input" value="1" min="1"
                       @if($product->track_stock) max="{{ $product->stock }}" @endif>
                <button type="button" class="qty-btn" onclick="adjustQty(1)">+</button>
            </div>
            <button type="submit" class="btn btn-primary btn-lg flex-grow-1" style="max-width:280px;">
                <i class="bi bi-cart-plus me-2"></i>Add to Cart
            </button>
        </form>
        @else
        <button class="btn btn-secondary btn-lg mb-3" disabled>Out of Stock</button>
        @endif

        {{-- Wishlist button --}}
        @auth
        <form method="POST" action="{{ route('wishlist.toggle', $product) }}" class="mb-4">
            @csrf
            <button type="submit"
                    class="btn {{ $inWishlist ? 'btn-danger' : 'btn-outline-danger' }} d-inline-flex align-items-center gap-2">
                <i class="bi bi-heart{{ $inWishlist ? '-fill' : '' }}"></i>
                {{ $inWishlist ? 'Saved to Wishlist' : 'Add to Wishlist' }}
            </button>
        </form>
        @else
        <div class="mb-4">
            <a href="{{ route('login') }}" class="btn btn-outline-secondary d-inline-flex align-items-center gap-2">
                <i class="bi bi-heart"></i> Save to Wishlist
            </a>
            <span class="text-muted small ms-2">Login required</span>
        </div>
        @endauth

        {{-- Meta --}}
        @if($product->sku)
        <div class="text-muted small"><strong>SKU:</strong> {{ $product->sku }}</div>
        @endif
    </div>
</div>

{{-- ════════════════════════════════════════════════════════
     REVIEWS SECTION
════════════════════════════════════════════════════════ --}}
<div id="reviews" class="pt-2">
    <h4 class="fw-bold mb-4">
        <i class="bi bi-star-fill text-warning me-2"></i>Customer Reviews
        @if($reviewCount > 0)
            <span class="text-muted fs-6 fw-normal ms-1">({{ $reviewCount }} reviews)</span>
        @endif
    </h4>

    <div class="row g-5">

        {{-- Rating summary --}}
        @if($reviewCount > 0)
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm p-4 text-center mb-4">
                <div class="display-4 fw-bold text-warning">{{ $avgRating }}</div>
                <div class="stars-lg mb-2">
                    @for($i=1;$i<=5;$i++)
                        <i class="bi bi-star{{ $i<=round($avgRating)?'-fill text-warning':' text-muted' }}"></i>
                    @endfor
                </div>
                <div class="text-muted small">Based on {{ $reviewCount }} review{{ $reviewCount!==1?'s':'' }}</div>
            </div>

            {{-- Distribution bars --}}
            <div class="card border-0 shadow-sm p-4">
                @foreach($distribution as $star => $count)
                @php $pct = $reviewCount > 0 ? round($count / $reviewCount * 100) : 0; @endphp
                <div class="d-flex align-items-center gap-2 mb-2">
                    <span class="text-muted small" style="width:14px;">{{ $star }}</span>
                    <i class="bi bi-star-fill text-warning" style="font-size:.7rem;"></i>
                    <div class="flex-grow-1 bg-light rounded" style="height:8px;">
                        <div class="bg-warning rounded" style="width:{{ $pct }}%;height:100%;"></div>
                    </div>
                    <span class="text-muted small" style="width:24px;">{{ $count }}</span>
                </div>
                @endforeach
            </div>
        </div>
        @endif

        {{-- Review list + form --}}
        <div class="col-lg-{{ $reviewCount > 0 ? '8' : '12' }}">

            {{-- Submit review form --}}
            @auth
            @if(!$userHasReviewed)
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white fw-semibold">
                    <i class="bi bi-pencil-square me-2"></i>Write a Review
                </div>
                <div class="card-body p-4">
                    <form method="POST" action="{{ route('reviews.store', $product) }}">
                        @csrf

                        {{-- Star selector --}}
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Your Rating <span class="text-danger">*</span></label>
                            <div class="star-picker" id="starPicker">
                                @for($s = 1; $s <= 5; $s++)
                                <button type="button" class="star-pick-btn" data-val="{{ $s }}"
                                        onclick="setRating({{ $s }})">
                                    <i class="bi bi-star"></i>
                                </button>
                                @endfor
                            </div>
                            <input type="hidden" name="rating" id="ratingInput"
                                   value="{{ old('rating') }}" required>
                            @error('rating')
                                <div class="text-danger small mt-1">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-semibold">Review Title</label>
                            <input type="text" name="title" class="form-control @error('title') is-invalid @enderror"
                                   value="{{ old('title') }}" placeholder="Summarise your experience…">
                            @error('title')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-semibold">Your Review</label>
                            <textarea name="body" class="form-control @error('body') is-invalid @enderror"
                                      rows="4" placeholder="Tell other customers what you think…">{{ old('body') }}</textarea>
                            @error('body')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>

                        <div class="alert alert-light border small mb-3">
                            <i class="bi bi-info-circle me-1"></i>
                            Reviews are published after administrator approval.
                        </div>

                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-send me-1"></i>Submit Review
                        </button>
                    </form>
                </div>
            </div>
            @else
            <div class="alert alert-success border-0 shadow-sm mb-4">
                <i class="bi bi-check-circle-fill me-2"></i>You have already submitted a review for this product.
            </div>
            @endif
            @else
            <div class="alert alert-light border shadow-sm mb-4">
                <i class="bi bi-person-circle me-2"></i>
                <a href="{{ route('login') }}">Login</a> to write a review.
            </div>
            @endauth

            {{-- Approved reviews list --}}
            @forelse($approvedReviews as $review)
            <div class="review-card mb-3">
                <div class="d-flex justify-content-between align-items-start gap-2 mb-2">
                    <div class="d-flex align-items-center gap-3">
                        <div class="review-avatar">{{ strtoupper(substr($review->user->name,0,1)) }}</div>
                        <div>
                            <div class="fw-bold">{{ $review->user->name }}</div>
                            <div class="text-muted small">{{ $review->created_at->format('Y-m-d') }}</div>
                        </div>
                    </div>
                    <div class="review-stars">
                        @for($i=1;$i<=5;$i++)
                            <i class="bi bi-star{{ $i<=$review->rating?'-fill text-warning':' text-muted' }}"
                               style="font-size:.85rem;"></i>
                        @endfor
                    </div>
                </div>
                @if($review->title)
                    <h6 class="fw-bold mb-1">{{ $review->title }}</h6>
                @endif
                @if($review->body)
                    <p class="text-muted small lh-lg mb-0">{{ $review->body }}</p>
                @endif

                {{-- Delete own review --}}
                @if(auth()->check() && $review->user_id === auth()->id())
                <form method="POST" action="{{ route('reviews.destroy', $review) }}" class="mt-2"
                      onsubmit="return confirm('Delete your review?')">
                    @csrf @method('DELETE')
                    <button class="btn btn-sm btn-outline-danger">
                        <i class="bi bi-trash me-1"></i>Delete My Review
                    </button>
                </form>
                @endif
            </div>
            @empty
            <div class="text-center text-muted py-4">
                <i class="bi bi-chat-square fs-2 d-block mb-2 opacity-25"></i>
                No approved reviews yet.
            </div>
            @endforelse
        </div>
    </div>
</div>

{{-- Related products --}}
@if($related->isNotEmpty())
<div class="mt-5 pt-4 border-top">
    <h5 class="fw-bold mb-4">Related Products</h5>
    <div class="row row-cols-2 row-cols-md-4 g-3">
        @foreach($related as $rel)
        <div class="col">
            <div class="card border-0 shadow-sm h-100 product-card-mini">
                @if($rel->main_image)
                <img src="{{ asset('storage/'.$rel->main_image) }}" class="card-img-top"
                     style="height:150px;object-fit:cover;" alt="{{ $rel->name }}">
                @endif
                <div class="card-body p-3">
                    <p class="small fw-semibold mb-1">
                        <a href="{{ route('shop.show', $rel->slug) }}" class="text-decoration-none text-dark">
                            {{ Str::limit($rel->name, 40) }}
                        </a>
                    </p>
                    <div class="fw-bold text-primary small">₩{{ number_format($rel->currentPrice()) }}</div>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endif

{{-- ════════════════════════════════════════════════════════
     LIGHTBOX MODAL
════════════════════════════════════════════════════════ --}}
<div id="lightbox" class="lightbox-overlay" onclick="closeLightboxOnBg(event)">
    <button class="lb-close" onclick="closeLightbox()"><i class="bi bi-x-lg"></i></button>
    <button class="lb-prev" onclick="lbNav(-1)"><i class="bi bi-chevron-left"></i></button>
    <button class="lb-next" onclick="lbNav(1)"><i class="bi bi-chevron-right"></i></button>

    <div class="lb-content">
        <img id="lbImg" src="" alt="" class="lb-img">
        <div id="lbCaption" class="lb-caption"></div>
    </div>
</div>

@endsection

@push('styles')
<style>
/* ── Product Gallery ─────────────────────────────────── */
.product-main-img-wrap {
    position: relative; cursor: zoom-in;
    border-radius: 16px; overflow: hidden;
    background: #f8f9fa; aspect-ratio: 1;
    border: 1px solid #eee;
}
.product-main-img { width:100%; height:100%; object-fit:cover; display:block; transition: transform .3s; }
.product-main-img-wrap:hover .product-main-img { transform: scale(1.04); }
.product-main-img-placeholder {
    display:flex; align-items:center; justify-content:center;
    width:100%; aspect-ratio:1; background:#f8f9fa;
}
.zoom-hint {
    position:absolute; bottom:12px; right:12px;
    background:rgba(0,0,0,.55); color:#fff;
    font-size:.72rem; padding:5px 10px; border-radius:20px;
    opacity:0; transition:opacity .2s;
}
.product-main-img-wrap:hover .zoom-hint { opacity:1; }

.thumb-strip { display:flex; gap:8px; flex-wrap:wrap; }
.thumb-item {
    width:70px; height:70px; border-radius:8px; overflow:hidden;
    cursor:pointer; border:2px solid transparent;
    transition:border-color .2s; flex-shrink:0;
}
.thumb-item img { width:100%; height:100%; object-fit:cover; }
.thumb-item.active { border-color: #0d6efd; }
.thumb-item:hover { border-color: #0d6efd88; }

/* ── Qty picker ──────────────────────────────────────── */
.qty-wrap { display:flex; align-items:center; border:1px solid #ced4da; border-radius:8px; overflow:hidden; }
.qty-btn {
    width:38px; height:44px; background:#f8f9fa; border:none;
    font-size:1.1rem; cursor:pointer; transition:background .15s;
}
.qty-btn:hover { background:#e9ecef; }
.qty-input {
    width:60px; height:44px; border:none; border-left:1px solid #ced4da;
    border-right:1px solid #ced4da; text-align:center;
    font-weight:700; font-size:.95rem; outline:none;
    -moz-appearance:textfield;
}
.qty-input::-webkit-outer-spin-button,.qty-input::-webkit-inner-spin-button{-webkit-appearance:none;}

/* ── Star picker ─────────────────────────────────────── */
.star-picker { display:flex; gap:6px; }
.star-pick-btn {
    background:none; border:none; cursor:pointer;
    font-size:1.8rem; color:#dee2e6; padding:0;
    transition:color .15s, transform .15s;
    line-height:1;
}
.star-pick-btn:hover,.star-pick-btn.active { color:#FFB300; }
.star-pick-btn.active { transform:scale(1.15); }

/* ── Reviews ─────────────────────────────────────────── */
.review-card {
    background:#fff; border-radius:12px;
    padding:20px; box-shadow:0 2px 12px rgba(0,0,0,.06);
    border:1px solid #f0f0f0;
}
.review-avatar {
    width:40px; height:40px; border-radius:50%;
    background:#0d6efd; color:#fff;
    display:flex; align-items:center; justify-content:center;
    font-weight:800; font-size:.9rem; flex-shrink:0;
}

/* ── Lightbox ────────────────────────────────────────── */
.lightbox-overlay {
    display:none; position:fixed; inset:0; z-index:9999;
    background:rgba(0,0,0,.92);
    align-items:center; justify-content:center;
}
.lightbox-overlay.open { display:flex; }
.lb-content { position:relative; max-width:90vw; max-height:90vh; }
.lb-img {
    max-width:90vw; max-height:88vh;
    object-fit:contain; border-radius:8px;
    display:block; user-select:none;
    transition:opacity .2s;
}
.lb-caption {
    text-align:center; color:rgba(255,255,255,.55);
    font-size:.8rem; margin-top:10px; letter-spacing:1px;
}
.lb-close,.lb-prev,.lb-next {
    position:fixed; background:rgba(255,255,255,.12);
    border:none; color:#fff; border-radius:50%;
    display:flex; align-items:center; justify-content:center;
    cursor:pointer; transition:background .2s;
    backdrop-filter:blur(4px);
}
.lb-close {
    top:20px; right:20px; width:44px; height:44px; font-size:1.1rem; z-index:10;
}
.lb-prev { left:20px; top:50%; transform:translateY(-50%); width:48px; height:48px; font-size:1.2rem; }
.lb-next { right:20px; top:50%; transform:translateY(-50%); width:48px; height:48px; font-size:1.2rem; }
.lb-close:hover,.lb-prev:hover,.lb-next:hover { background:rgba(255,255,255,.25); }
.lb-prev:disabled,.lb-next:disabled { opacity:.3; cursor:default; }

/* ── Product card mini ───────────────────────────────── */
.product-card-mini { transition:transform .2s; }
.product-card-mini:hover { transform:translateY(-3px); }
</style>
@endpush

@push('scripts')
<script>
// ── Thumbnail switcher ──────────────────────────────────────
const imageUrls = @json($imageUrls);

function switchMain(index, thumbEl) {
    document.getElementById('mainDisplay').src = imageUrls[index];
    document.querySelectorAll('.thumb-item').forEach((t,i) => t.classList.toggle('active', i===index));
    currentLbIndex = index;
}

// ── Qty adjuster ────────────────────────────────────────────
function adjustQty(delta) {
    const input = document.getElementById('qtyInput');
    const val = parseInt(input.value) + delta;
    const min = parseInt(input.min) || 1;
    const max = parseInt(input.max) || 9999;
    input.value = Math.max(min, Math.min(max, val));
}

// ── Star rating picker ───────────────────────────────────────
let currentRating = {{ old('rating', 0) }};
if (currentRating > 0) applyRatingUI(currentRating);

function setRating(val) {
    currentRating = val;
    document.getElementById('ratingInput').value = val;
    applyRatingUI(val);
}

function applyRatingUI(val) {
    document.querySelectorAll('.star-pick-btn').forEach((btn, i) => {
        const v = parseInt(btn.dataset.val);
        const icon = btn.querySelector('i');
        icon.className = v <= val ? 'bi bi-star-fill' : 'bi bi-star';
        btn.style.color = v <= val ? '#FFB300' : '#dee2e6';
    });
}

// Hover effects on stars
document.querySelectorAll('.star-pick-btn').forEach(btn => {
    btn.addEventListener('mouseenter', () => {
        const v = parseInt(btn.dataset.val);
        document.querySelectorAll('.star-pick-btn').forEach((b,i) => {
            b.querySelector('i').className = parseInt(b.dataset.val) <= v ? 'bi bi-star-fill' : 'bi bi-star';
            b.style.color = parseInt(b.dataset.val) <= v ? '#FFB300' : '#dee2e6';
        });
    });
    btn.addEventListener('mouseleave', () => applyRatingUI(currentRating));
});

// ── Lightbox ────────────────────────────────────────────────
let currentLbIndex = 0;

function openLightbox(index) {
    if (!imageUrls.length) return;
    currentLbIndex = index;
    updateLightboxImg();
    document.getElementById('lightbox').classList.add('open');
    document.body.style.overflow = 'hidden';
}

function closeLightbox() {
    document.getElementById('lightbox').classList.remove('open');
    document.body.style.overflow = '';
}

function closeLightboxOnBg(e) {
    if (e.target === document.getElementById('lightbox')) closeLightbox();
}

function lbNav(dir) {
    currentLbIndex = (currentLbIndex + dir + imageUrls.length) % imageUrls.length;
    updateLightboxImg();
}

function updateLightboxImg() {
    const img = document.getElementById('lbImg');
    img.style.opacity = '0';
    setTimeout(() => {
        img.src = imageUrls[currentLbIndex];
        img.style.opacity = '1';
    }, 120);
    document.getElementById('lbCaption').textContent =
        imageUrls.length > 1 ? `${currentLbIndex + 1} / ${imageUrls.length}` : '';
    document.querySelector('.lb-prev').disabled = imageUrls.length <= 1;
    document.querySelector('.lb-next').disabled = imageUrls.length <= 1;
}

// Keyboard navigation
document.addEventListener('keydown', e => {
    if (!document.getElementById('lightbox').classList.contains('open')) return;
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowLeft') lbNav(-1);
    if (e.key === 'ArrowRight') lbNav(1);
});
</script>
@endpush
